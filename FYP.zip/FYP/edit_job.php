<?php 
session_start();
include 'include/con.php';
include 'include/header.php';
$sql="select * from jobs where id=".$_GET['id'];
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);
?>

<body style="font-family:Sansation Light">

    <div id="status"></div>

    <?php include 'include/nav.php'; ?>


    <section class="features">
        <div class="container">
            <div class="row">
                <div class="col-md-4" style="font-family:Sansation Light">
                    <h2>Post A Job</h2>
<p><i class="fa fa-hand-o-right"></i><a href="all_jobs.php" style="color: white;"> All Jobs</a></p>
  <p><i class="fa fa-hand-o-right"></i><a href="applications.php" style="color: white;">Candidates applications</a></p>
                </div>
                <div class="col-md-8" style="font-family:Sansation Light">
<form method="POST" action="action.php">
  <div class="form-group row">
    <label class="col-sm-2 col-form-label">Job Title</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="title" value="<?php echo $row['title']; ?>" required >
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Category</label>
    <div class="col-sm-10">
       <select class="form-control" name="cat">
    <option value="Web Development" <?php echo ($row['category']=='Web Development')?'selected':''; ?> >Web Development</option>
    <option value="Web Desiging" <?php echo ($row['category']=='Web Desiging')?'selected':''; ?> >Web Desiging</option>
    <option value="Graphics Designer" <?php echo ($row['category']=='Graphics Designer')?'selected':''; ?> >Graphics Designer</option>
    <option value="Unity Development" <?php echo ($row['category']=='Unity Development')?'selected':''; ?>>Unity Development</option>
    <option value="Andriod Apps Development" <?php echo ($row['category']=='Andriod Apps Development')?'selected':''; ?>>Andriod Apps Development</option>
    <option value="IOS Apps Development" <?php echo ($row['category']=='IOS Apps Development')?'selected':''; ?>>IOS Apps Development</option>
    <option value="Desktop Development" <?php echo ($row['category']=='Desktop Development')?'selected':''; ?>>Desktop Development</option>
    <option value="Others" <?php echo ($row['category']=='Others')?'selected':''; ?>>Others</option>
       </select>
    </div>
  </div>
  <div class="form-group row">
    <label class="col-sm-2 col-form-label">Job Description</label>
    <div class="col-sm-10">
      <textarea class="form-control" name="description" required ><?php echo $row['description']; ?></textarea>
    </div>
  </div>
  <div class="form-group row">
    <label class="col-sm-2 col-form-label">Job Location</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo $row['location']; ?>" name="location" required > 
    </div>
  </div>
  <div class="form-group row">
    <label class="col-sm-2 col-form-label">Job Status</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo $row['status']; ?>" name="status" required > 
    </div>
  </div>
   <div class="form-group row">
    <label class="col-sm-2 col-form-label">Salary Range</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo $row['salary']; ?>" name="salary" required > 
    </div>
  </div>
   <div class="form-group row">
    <label class="col-sm-2 col-form-label">Time Shift</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" name="time" value="<?php echo $row['time']; ?>" required > 
    </div>
  </div>
  <div class="form-group row">
    <label class="col-sm-2 col-form-label">Experience Required</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" name="exp" value="<?php echo $row['experience']; ?>" required > 
    </div>
  </div>
  <div class="form-group row">
    <button type="submit" class="btn btn-success">Update JOB POST</button>
  </div>
  <input type="hidden" name="job_edit">
  <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
</form>
                </div>
            </div>
        </div>
    </section>
    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <h5><a href="index.html"> Go Resume</a></h5>
                </div>
                <div class="col-sm-6 social-icons"><a href="https://www.facebook.com/Go-Resume-1813690295611919/" target="_blank"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-instagram"></i></a></div>
            </div>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
