<?php
session_start();
include '../include/con.php';
if (isset($_SESSION['userid'])) {
	$userid=$_SESSION['userid'];
}else{
    $userid=$_GET['id'];
}
$sql="select * from users where id=".$userid;
    $result=mysqli_query($con,$sql); 
    $row=mysqli_fetch_array($result);
     function select($name,$con,$userid) {
         $sql="select * from ".$name." where user_id=".$userid;
            $result=mysqli_query($con,$sql);
            return $result;
         }
?>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.debug.js"></script>
	<script src="../js/jspdf.min.js"></script>
	<script src="../js/html2canvas.min.js"></script>
	<script src="../js/html2pdf.js"></script>
	 <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
	<title><?php echo ucwords($row['name']); ?> Resume</title>
	<meta name="robots" content="noindex, nofollow">
	<style type="text/css" media="all">
		html{
			background-color:#FFF;
			padding:0 1em;
			}
		body {
			background-color:#FFF;
			font-family:"Trebuchet MS";
			padding:1em;
			margin:1em auto;
			max-width: 50em;
			}
		#address{
			height:5em;
			width:48em;
			padding:1em;
			}
		#address div{
			width:16em;
			float:left;
			}
		#address h3{
			border-bottom: none;
			font-variant: small-caps;
			margin-top: 0;
			}	
		.date {
			float:right;
			font-size:.8em;
			margin-top:.4em;
			text-align:right;
			}
		abbr, acronym{
			border-bottom:1px dotted #333;
			cursor:help;
			}	
		address{
			font-style:italic;
			color:#333;
			font-size:.9em;
			}
		.content{
			width:32em;
			margin:0 0 0 16em;
			}	
		.section{
			border-top:1px solid #ccc;
			margin:1em 0;
			padding:1em;
			}
		ul{
			padding-left:.5em;
			margin-left:.5em;
			}
		h1{
			margin:1em 0 1em 9.5em;
			font-size:1.75em;
			}
		h2 {
			width:14em;
			float:left;
			font-size:1em;
			font-variant: small-caps;
			letter-spacing: .06em;
			}
		h3 {margin-bottom: 0;}
	</style>
	<style type="text/css" media="print">
		body {
			background-color:#FFF;
			border-width:0 0 0 0;
			margin:0;
			width:100%
			}
	</style>
	<script type="text/javascript" src="../js/getData.js"></script>
</head>
<body>
    
<div id="resume4">
<h1><?php echo ucwords($row['name']); ?></h1>

	<div id="address">
		<div>
			<h3>Local Address</h3>
			<?php echo ucwords($row['address']); ?>
		</div>
		<div id="first">
			<h3>Contact</h3>
			<?php echo "+92-".ucwords($row['phone_no']); ?>

			<?php echo ucwords($row['gmail']); ?>
		</div>
		<div>
			<h3>Permanent Address</h3>
			<?php echo ucwords($row['address']); ?>
		</div>
	</div>
	
	<div class="section">
		<h2>Relevant Qualifications</h2>
		<div class="content">
		
	<ul>
	  <?php
         $result2=select('relevant_qualifications',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<li>".$key['qualification']."</li>";
         }
      ?>
			</ul>
		</div>
	</div>
	
	<div class="section">
		<h2>Work Experience</h2>
		<div class="content">
			 <?php
         $result2=select('Work_Details',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<span class='date'>".$key['start_date']." to ".$key['end_date']."</span><h3>".$key['position']."</h3><address>".$key['company']."</address>";
         }
      ?>
		</div>
	</div>
	
	<div class="section">
		<h2>Interest / Volunteer</h2>
		<div class="content">
			<h3>Personal Skills</h3>
			<ul>
	<?php
         $result2=select('skills',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<li>".$key['skills']."</li>";
         }
    ?>
			</ul>
			<h3>Professional Skills</h3>
			<ul>
			<?php
         $result2=select('technical_skills',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<li>".$key['technical skill']."</li>";
         }
        ?>
			</ul>
		</div>
	</div>
	
	<div class="section">
		<h2>Education</h2>
		<div class="content">
			<ul>
				<?php
         $result2=select('Academic',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<span class='date'>".$key['date']."</span><h3>".$key['degree']."</h3><address>".$key['institute']."</address>";
         }
      ?>
			</ul>
		</div>
	</div>
</div>
<hr style="border: 1px solid #A2AEBB; margin-right: 10%" />
<button class="buttom" onclick="convert2pdf()" type="button" style="position: relative; float: right; margin-right: 10%">Download Resume</button><button class="buttom" onclick="window.open('../cvhome.php','_SELF');" type="button" style="position: relative; float: right;margin-right:5px; ">Home Page</button><br><br>
<script type="text/javascript">
    function convert2pdf() {
        var element = document.getElementById("resume4");
        html2pdf(element, {margin: 5});
    }
</script>
 <div style="float:right"
  class="fb-like"
  data-share="true"
  data-width="450"
  data-show-faces="true">
</div>

</body></html>