<?php
session_start();
include '../include/con.php';
if (isset($_SESSION['userid'])) {
	$userid=$_SESSION['userid'];
}else{
    $userid=$_GET['id'];
}
$sql="select * from users where id=".$userid;
    $result=mysqli_query($con,$sql); 
    $row=mysqli_fetch_array($result);
     function select($name,$con,$userid) {
         $sql="select * from ".$name." where user_id=".$userid;
            $result=mysqli_query($con,$sql);
            return $result;
         }
?>
<html>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.debug.js"></script>
	<script src="../js/jspdf.min.js"></script>
	<script src="../js/html2canvas.min.js"></script>
	<script src="../js/html2pdf.js"></script>
	<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
	 <meta charset="utf-8">
	<title><?php echo ucwords($row['name']); ?> Resume</title>
	<meta name="robots" content="noindex, nofollow">
	<style type="text/css" media="all">
		html{
			background-color:#444;
			background: url(/posts/backgrounds/images/20.gif);
			padding:0 1em;
			}
		body {
			background-color:#FFF;
			font-family:Arial, Helvetica, sans-serif;
			padding:2em;
			margin:1em auto;
			border:2px solid #000;
			max-width: 50em;
			}
		#address{
			float:right;
			padding-top:2.5em;
			}
		#contact{
			text-align:right;
			}
		.date {
			float:left;
			font-size:1em;
			margin:0 0 0 -16em;
			text-align:right;
			}
		abbr, acronym{
			border-bottom:1px dotted #333;
			cursor:help;
			}	
		address{
			font-style:italic;
			color:#333;
			font-size:.9em;
			}
		.content{
			width:32em;
			margin:0 0 0 16em;
			}	
		.section{
			margin: 0;
			padding:1em 0;
			}
		ul{
			padding-left:.5em;
			margin-left:.5em;
			}
		h1{
			margin:0 0 .1em 0;
			padding:1em 0 0 0;
			font-size:1.75em;
			border-bottom:3px double #000;
			}
		h2 {
			font-size:1.3em;
			font-variant: small-caps;
			letter-spacing: .06em;
			border-bottom:1px solid #000;
			}
		.section h3 {
			font-size:1em;
			font-variant: small-caps;
			margin-bottom:0;
			width:14em;
			}
	</style>
	<style type="text/css" media="print">
		body {
			background-color:#FFF;
			border-width:0 0 0 0;
			margin:0;
			width:100%
			}
	</style>
	<script type="text/javascript" src="../js/getData.js"></script>
</head>
<body>
<div id="resume5">
	<div id="address">
		<?php echo ucwords($row['address']); ?>
	</div>
	<h1><?php echo ucwords($row['name']); ?></h1>
	<div id="contact">
		<h3>Contact</h3>
		<?php echo "+92-".ucwords($row['phone_no']); ?>

		<?php echo ",".ucwords($row['email']); ?>
	</div>
	
	<div class="section">
		<h2>Relevant Qualifications</h2>
			<ul>
				<?php
         $result2=select('relevant_qualifications',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<li>".$key['qualification']."</li>";
         }
      ?> 
			</ul>
	</div>
	
	<div class="section">
		<h2>Work Experience</h2>
		<div class="content">
	<?php
         $result2=select('Work_Details',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<span class='date'>".$key['start_date']." to ".$key['end_date']."</span><h3>".$key['position']."</h3><address>".$key['company']."</address>";
         }
      ?>
		</div>
	</div>
	
	<div class="section">
		<h2>Volunteer Experience</h2>
		<div class="content">
			<h3>Personal Skills</h3>
			<ul>
		<?php
         $result2=select('skills',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<li>".$key['skills']."</li>";
         }
        ?> 
			</ul>
			<h3>Professional Skills</h3>
			<ul>
			   <?php
         $result2=select('technical_skills',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<li>".$key['technical skill']."</li>";
         }
        ?>
			</ul>
		</div>
	</div>
	
	<div class="section">
		<h2>Education</h2>
			<ul>
				<?php
         $result2=select('Academic',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<li><h3>".$key['degree']."</h3><span > From ".$key['institute'].", In ".$key['date']."</span></li>";
         }
           ?>  
			</ul>
	</div>
</div>
	<hr style="border: 1px solid #A2AEBB; margin-right: 10%" />
	<button class="buttom" onclick="convert2pdf()" type="button" style="position: relative; float: right; margin-right: 10%">Download</button><button class="buttom" onclick="window.open('../cvhome.php','_SELF');" type="button" style="position: relative; float: right;margin-right:5px; ">Home Page</button><br><br>
	<script type="text/javascript">
        function convert2pdf() {
            var element = document.getElementById("resume5");
            html2pdf(element, {margin: 5});
        }
	</script>
<div style="float:right"
  class="fb-like"
  data-share="true"
  data-width="450"
  data-show-faces="true">
</div>

</body></html>