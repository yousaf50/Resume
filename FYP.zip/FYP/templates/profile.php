<?php
session_start();
include '../include/con.php';
$sql="select * from users where id=".$_GET['id'];
    $result=mysqli_query($con,$sql); 
    $row=mysqli_fetch_array($result);
     function select($name,$con) {
            $sql="select * from ".$name." where user_id=".$_GET['id'];
            $result=mysqli_query($con,$sql);
            return $result;
         }
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<script src="../js/jspdf.min.js"></script>
	<script src="../js/html2canvas.min.js"></script>
	<script src="../js/html2pdf.js"></script>
	<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
	 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	
	<title>Resume | First Last</title>
	<meta name="robots" content="noindex, nofollow">
	<style type="text/css" media="all">
		html{
			/*background-color:#EEE;*/
			padding:0 1em;
			}
		body {
			background-color:#FFF;
			font-family:"Trebuchet MS", Helvetica, Arial;
			padding:1em;
			border:solid #AAA;
			border-width:1px 3px 3px 1px;
			margin:1em auto;
			max-width: 50em;
			}
		#address{
			height:5em;
			width:47em;
			margin:1em 0 1em 0;
			}
		#address div{
			width:13em;
			float:left;
			padding:0 .5em 0 1.5em;
			border-left:1px solid #CCC;
			}
		#address div#first{
			border-left:none;
			}
		#address h3{
			border-bottom: none;
			margin-top: 0;
			}	
		.date {
			float:right;
			font-size:.8em;
			margin-top:.4em;
			text-align:right;
			}
		abbr, acronym{
			border-bottom:1px dotted #333;
			cursor:help;
			}	
		address{
			font-style:italic;
			color:#333;
			font-size:.9em;
			}
			
		
		h1{
			font-size:1.5em;
			font-family: Helvetica, Verdana, Arial, sans-serif;
			}
		h2 {
			clear:both;
			font-size: 1.4em;
			font-weight:bold;
			margin-top:2em;
			font-variant: small-caps;
			padding-left:.25em;
			background-color:#EEE;
			border-bottom: 1px solid #999;
			letter-spacing: .06em;
			}
		h3 {margin: 1em 0 0 0;}
	</style>
	<style type="text/css" media="print">
		body {
			background-color:#FFF;
			border-width:0 0 0 0;
			margin:0;
			width:100%
			}
	</style>
	<script type="text/javascript" src="../js/getData.js"></script>
</head>
<body>
    <div id="fb-root"></div>
   
    <div id="status"></div>

<div id="resume1">
    <h1><?php echo ucwords($row['name']); ?></h1>
	<div id="address">
		<div id="first">
			<h3>Contact</h3>
            <?php echo ucwords($row['phone_no']); ?>
            <?php echo ucwords($row['email']); ?>
		</div>

		<div>
			<h3>Local Address</h3>
           <?php echo ucwords($row['address']); ?>
		</div>

		<div>
			<h3>Permanent Address</h3>
            <?php echo ucwords($row['address']); ?>
		</div>
	</div>
	<h2>Relevant Qualifications</h2>
	<ul>
	  <?php
         $result2=select('relevant_qualifications',$con);
          foreach ($result2 as $key) {
         	echo "<li>".$key['qualification']."</li>";
         }
      ?>      
	</ul>	
	<h2>Work Experience</h2>
    <?php
         $result2=select('Work_Details',$con);
          foreach ($result2 as $key) {
         	echo "<span class='date'>".$key['start_date']." to ".$key['end_date']."</span><h3>".$key['position']."</h3><address>".$key['company']."</address>";
         }
      ?>

	<h2>Interest / Skills</h2>
	<h3>Personal Skills</h3>
	<ul>
		<?php
         $result2=select('skills',$con);
          foreach ($result2 as $key) {
         	echo "<li>".$key['skills']."</li>";
         }
        ?> 
	</ul>
	<h3>Professional Skills</h3>
	<ul>
		<?php
         $result2=select('technical_skills',$con);
          foreach ($result2 as $key) {
         	echo "<li>".$key['technical skill']."</li>";
         }
        ?>
	</ul>
	
	<h2>Education</h2>
<?php
         $result2=select('Academic',$con);
          foreach ($result2 as $key) {
         	echo "<span class='date'>".$key['date']."</span><h3>".$key['degree']."</h3><address>".$key['institute']."</address>";
         }
      ?>
 <br><br>


	<div id="editor"></div>

</div>

<hr style="border: 1px solid #A2AEBB; margin-right: 10%" />
<button class="buttom" onclick="convert2pdf()" type="button" style="position: relative; float: right; margin-right: 10%">Download Resume</button><button class="buttom" onclick="window.open('../cvhome.php','_SELF');" type="button" style="position: relative; float: right;margin-right:5px; ">Home Page</button><br><br>
<script type="text/javascript">
    function convert2pdf() {
        var element = document.getElementById("resume1");
        html2pdf(element, {margin: 5});
    }
</script>
 <div style="float:right"
  class="fb-like"
  data-share="true"
  data-width="450"
  data-show-faces="true">
</div>
<!--<div class="fb-share-button" data-href="https://www.facebook.com/goresume1" data-layout="button_count" data-size="small" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fhttps%2Fwww.facebook.com%2Fgoresume1&amp;src=sdkpreparse">Share</a></div>-->
<!-- <a class="btn btn-success"  role="button" href="mailto:companyname@example.com?subject=hello" target="_blank" />Send Mail</a> -->
<!--<a href="mailto:someone@example.com?subject=hello">Send Mail</a>-->
</body>

</html>