<?php
session_start();
include '../include/con.php';
if (isset($_SESSION['userid'])) {
	$userid=$_SESSION['userid'];
}else{
    $userid=$_GET['id'];
}
$sql="select * from users where id=".$userid;
    $result=mysqli_query($con,$sql); 
    $row=mysqli_fetch_array($result);
     function select($name,$con,$userid) {
         $sql="select * from ".$name." where user_id=".$userid;
            $result=mysqli_query($con,$sql);
            return $result;
         }
?>
<html>
<head>

	<script src="../js/jspdf.min.js"></script>
	<script src="../js/html2canvas.min.js"></script>
	<script src="../js/html2pdf.js"></script>

	<script type="text/javascript" src="../js/getData.js"></script>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />

	<link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/2.7.0/build/reset-fonts-grids/reset-fonts-grids.css" media="all" />
<title><?php echo ucwords($row['name']); ?> Resume</title>
	<style type="text/css">

		.msg { padding: 10px; background: #222; position: relative; }
		.msg h1 { color: #fff;  }
		.msg a { margin-left: 20px; background: #408814; color: white; padding: 4px 8px; text-decoration: none; }
		.msg a:hover { background: #266400; }

		/* //-- yui-grids style overrides -- */
		body { font-family: Georgia; color: #444; }
		#inner { padding: 10px 80px; margin: 80px auto; background: #f5f5f5; border: solid #666; border-width: 8px 0 2px 0; }
		.yui-gf { margin-bottom: 2em; padding-bottom: 2em; border-bottom: 1px solid #ccc; }

		/* //-- header, body, footer -- */
		#hd { margin: 2.5em 0 3em 0; padding-bottom: 1.5em; border-bottom: 1px solid #ccc }
		#hd h2 { text-transform: uppercase; letter-spacing: 2px; }
		#bd, #ft { margin-bottom: 2em; }

		/* //-- footer -- */
		#ft { padding: 1em 0 5em 0; font-size: 92%; border-top: 1px solid #ccc; text-align: center; }
		#ft p { margin-bottom: 0; text-align: center;   }

		/* //-- core typography and style -- */
		#hd h1 { font-size: 48px; text-transform: uppercase; letter-spacing: 3px; }
		h2 { font-size: 152% }
		h3, h4 { font-size: 122%; }
		h1, h2, h3, h4 { color: #333; }
		p { font-size: 100%; line-height: 18px; padding-right: 3em; }
		a { color: #990003 }
		a:hover { text-decoration: none; }
		strong { font-weight: bold; }
		li { line-height: 24px; border-bottom: 1px solid #ccc; }
		p.enlarge { font-size: 144%; padding-right: 6.5em; line-height: 24px; }
		p.enlarge span { color: #000 }
		.contact-info { margin-top: 7px; }
		.first h2 { font-style: italic; }
		.last { border-bottom: 0 }


		/* //-- section styles -- */

		a#pdf { display: block; float: left; background: #666; color: white; padding: 6px 50px 6px 12px; margin-bottom: 6px; text-decoration: none;  }
		a#pdf:hover { background: #222; }

		.job { position: relative; margin-bottom: 1em; padding-bottom: 1em; border-bottom: 1px solid #ccc; }
		.job h4 { position: absolute; top: 0.35em; right: 0 }
		.job p { margin: 0.75em 0 3em 0; }

		.last { border: none; }
		.skills-list {  }
		.skills-list ul { margin: 0; }
		.skills-list li { margin: 3px 0; padding: 3px 0; }
		.skills-list li span { font-size: 152%; display: block; margin-bottom: -2px; padding: 0 }
		.talent { width: 32%; float: left }
		.talent h2 { margin-bottom: 6px; }

		#srt-ttab { margin-bottom: 100px; text-align: center;  }
		#srt-ttab img.last { margin-top: 20px }

		/* --// override to force 1/8th width grids -- */
		.yui-gf .yui-u{width:80.2%;}
		.yui-gf div.first{width:12.3%;}



	</style>

</head>
<body>

<div id="resume7" class="yui-t7">
	<div id="inner">
	
		<div id="hd">
			<div class="yui-gc">
				<div class="yui-u first">
					<h1><?php echo ucwords($row['name']); ?></h1>
				</div>

				<div class="yui-u">
					<div class="contact-info">

		<h3><?php echo ucwords($row['email']); ?></h3>
		<h3><?php echo ucwords($row['phone_no']); ?></h3>

					
					</div><!--// .contact-info -->
				</div>
			</div><!--// .yui-gc -->
		</div><!--// hd -->

		<div id="bd">
			<div id="yui-main">
				<div class="yui-b">

					<div class="yui-gf">
						<div class="yui-u first">
							<h2>Profile</h2>
						</div>
						<div class="yui-u">
							<p class="enlarge">
								Progressively evolve cross-platform ideas before impactful infomediaries. Energistically visualize tactical initiatives before cross-media catalysts for change. 
							</p>
						</div>
					</div><!--// .yui-gf -->

					<div class="yui-gf">
						<div class="yui-u first">
							<h2>Skills</h2>
						</div>
						<div class="yui-u">

								<div class="talent">
									<h2>Technical Skills</h2>

							<ul class="talent">
					<?php
         $result2=select('skills',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<li><p>".$key['skills']."</p></li>";
         }
        ?>
		 </ul>
</div>

								<div class="talent">
									<h2>Personal Skills</h2>

									<ul class="talent">
	<?php
         $result2=select('technical_skills',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<li><p>".$key['technical skill']."</p></li>";
         }
        ?> </ul>
</div>
</div>
</div>
					<div class="yui-gf">
	
						<div class="yui-u first">
							<h2>Experience</h2>
						</div><!--// .yui-u -->

						
<?php
         $result2=select('Work_Details',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<div class='yui-u'><div class='job'><h2>".$key['position']."</h2><h3>".$key['company']."</h3><h4>".$key['start_date']." - ".$key['end_date']."</h4></div>
					</div>";
         }
      ?>
</div>
<div class="yui-gf last">
<div class="yui-u first">
   <h2>Education</h2>
</div>
<?php
    $result2=select('Academic',$con,$userid);
     foreach ($result2 as $key) {
      echo "<div class='yui-u'>
<h2>".$key['degree']."</h2><h3>".$key['institute']."</h3> - 
<strong>".$key['date']."</strong></div>";
         }
      ?>				
</div><!--// .yui-gf -->
</div><!--// .yui-b -->
</div><!--// yui-main -->
		</div><!--// bd -->

		><!--// footer -->

	</div><!-- // inner -->

</div><!--// doc -->

<hr style="border: 1px solid #A2AEBB; margin-right: 10%" />
<button class="buttom" onclick="convert2pdf()" type="button" style="position: relative; float: right; margin-right: 10%">Download Resume</button><button class="buttom" onclick="window.open('../cvhome.php','_SELF');" type="button" style="position: relative; float: right;margin-right:5px; ">Home Page</button><br><br>
<script type="text/javascript">
    function convert2pdf() {
        var element = document.getElementById("resume7");
        html2pdf(element, {margin: 5});
    }
</script>

</body>
</html>

