<?php
$con=mysqli_connect("localhost", "root", "123456", "FYP");

 if(!$con)
 {
 	die("Connection Failed: ". mysqli_connect_error());
 }

?>