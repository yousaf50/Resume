<?php 
session_start();
?>
<!DOCTYPE html>
<html>

<title style="font-family:Sansation Light">Go Resume</title>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->

<script src="https://www.gstatic.com/firebasejs/4.1.3/firebase.js"></script>
    <script src="/__/firebase/4.1.3/firebase-app.js"></script>
    <script src="/__/firebase/4.1.3/firebase-auth.js"></script>
    <script src="/__/firebase/4.1.3/firebase-database.js"></script>
    <script src="/__/firebase/4.1.3/firebase-messaging.js"></script>
   
</head>
<body style="font-family:Sansation Light">
<script src="include/sweetalert.js"></script>
<?php  if(isset($_GET['msg']) && $_GET['msg']=='inserted'){ ?>
<script type="text/javascript">
swal("Good job!", "Sign Up Successfully!", "success");
</script>
<?php }elseif(isset($_GET['msg']) && $_GET['msg']=='login'){ ?>
<script type="text/javascript">
swal("Good job!", "LOGIN Successfully!", "success");
</script>
<?php }elseif(isset($_GET['msg']) && $_GET['msg']=='nologin'){ ?>
<script type="text/javascript">
swal("Ouch!", "Email OR Password is Wrong!", "error");
</script>
<?php }elseif (isset($_GET['msg'])) {  ?>
<script type="text/javascript">
   swal("Ouch!", "Try again!", "error");
</script>
<?php } ?>
    <div id="status"></div>

    <nav class="navbar navbar-inverse">
        <div class="container" style="font-family:Sansation Light">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="index.html">⚡Go Resume</a>
            </div>
           
            <!-- <div style="float:right" class="fb-login-button" data-max-rows="1" data-size="large" data-button-type="continue_with" data-show-faces="false"
                data-auto-logout-link="false" data-use-continue-as="false"></div>
            <div class="collapse navbar-collapse" id="navcol-1">

 <div style="float:right"
  class="fb-like"
  data-share="true"
  data-width="450"
  data-show-faces="true">
</div>-->
<?php if (isset($_SESSION['userid'])) {
    echo '<a class="btn btn-success navbar-btn navbar-right"
                            role="button" href="action.php?logout=ok" />Log Out</a>';
    echo "<a class='btn btn-primary navbar-btn navbar-right'>Hello ".$_SESSION['name']."</a>";
}else{ ?>
<a class="btn btn-primary navbar-btn navbar-right" data-toggle="modal" data-target="#myModal"
                            role="button"/>Sign UP</a>
<a class="btn btn-success navbar-btn navbar-right"
                            data-toggle="modal" data-target="#myModal2"
                            role="button" />Login</a>
<?php } ?>                            
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Sign Up to Go Resume</h4>
        </div>
<form class="form-horizontal" action="action.php" method="POST" name="signup">

        <div class="modal-body">

    <div class="form-group">
    <label  class="col-sm-2 control-label">Name</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="signupname" placeholder="Your Name" required>
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10">
      <input type="email" class="form-control" name="email" placeholder="Your Email" required>
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" name="password" placeholder="Password" required>
    </div>
  </div>
         
        </div>
        <div class="modal-footer">
             <input type="hidden" name="signup">
<button type="submit"  class="btn btn-info">Sign Up</button>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>        </div>
</form>

      </div>
      
    </div>
  </div>
  <!-- modal end -->
  
</div>

                <ul class="nav navbar-nav navbar-right"></ul>
            </div>
        </div>
    </nav>
    <div class="jumbotron hero" style="font-family:Sansation Light">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-4 col-md-pull-3 get-it">
        <h1 class="text-muted">Go Resume</h1>
        <p>Create Unlimited Resumes, Explore Jobs, Publish your resumes, Share them on Social Media.</p>
        <p><a class="btn btn-primary btn-lg" role="button" onclick="fun();" target="_self">Create Resume</a><a
                            class="btn btn-success btn-lg" role="button" <base href="jobs.php" target="_self" />Explore
                        Jobs</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <section class="testimonials" style="font-family:Sansation Light">

        
        <h2 class="text-center">It's Free.!</h2>
        <blockquote>
            <p>This is a non-profit application, that allows you to increase you productivity, &amp; explore what suits you
                the best.</p>
        </blockquote>
    </section>
    <section class="features">
        <div class="container">
            <div class="row">
                <div class="col-md-6" style="font-family:Sansation Light">
                    <h2>Fantastic Features</h2>
                    <p>Create unlimited resumes, Publish them, share them. Explore for jobs</p>
                </div>
                <div class="col-md-6" style="font-family:Sansation Light">
                    <div class="row icon-features">
                        <div class="col-xs-4 icon-feature"><i class="glyphicon glyphicon-flash"></i>
                            <p>Fast</p>
                        </div>
                        <div class="col-xs-4 icon-feature"><i class="glyphicon glyphicon-piggy-bank"></i>
                            <p>Free</p>
                        </div>
                        <div class="col-xs-4 icon-feature"><i class="glyphicon glyphicon-hand-right"></i>
                            <p>Secure</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <h5>Go Resume</h5>
                </div>
                <div class="col-sm-6 social-icons"><a href="https://www.facebook.com/Go-Resume-1813690295611919/" target="_blank"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-instagram"></i></a></div>
            </div>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>


<div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
     <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Login Go Resume</h4>
        </div>
<form class="form-horizontal" action="action.php" method="POST" >
<div class="modal-body">

  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10">
      <input type="email" class="form-control" name="email" placeholder="Your Email" required>
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" name="password" placeholder="Password" required>
    </div>
  </div>
         
        </div>
        <div class="modal-footer">
            <input type="hidden" name="login">
<button type="submit"  class="btn btn-info">LOG IN</button>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>        </div>
</form>

      </div>
      
    </div>
  </div>
  <!-- modal end -->
</html>
<script type="text/javascript">
    function fun() {
      var id=<?php echo (isset($_SESSION['userid'])?$_SESSION['userid']:'0'); ?>;  
        if (id==0) {
           swal("LOGIN Ist, To Create Resume!"); 
        }else{
            window.open('builder.php','_SELF');
            exit();
        }
    }
</script>