/**
 * Created by AdeelAhmedMirza on 7/17/2017.
 */
$('#subject-select').dropdown();