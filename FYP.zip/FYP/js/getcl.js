/**
 * Created by AdeelAhmedMirza on 7/29/2017.
 */

var ggName = localStorage.getItem("ssName");
var ggEmail = localStorage.getItem("ssEmail");
var ggPhone = localStorage.getItem("ssPhone");
var ggAddress = localStorage.getItem("ssAddress");
var ggDate = localStorage.getItem("ssDate");
var ggSel1 = localStorage.getItem("ssSel1");
var ggcName = localStorage.getItem("sscName");
var ggcTitle = localStorage.getItem("sscTitle");
var ggcOrg = localStorage.getItem("sscOrg");
var ggcAddress = localStorage.getItem("sscAddress");
var ggStart = localStorage.getItem("ssStart");
var ggMid = localStorage.getItem("ssMid");
var ggEnd = localStorage.getItem("ssEnd");
var ggSel2 = localStorage.getItem("ssSel2");
