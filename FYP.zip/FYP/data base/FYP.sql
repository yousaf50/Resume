-- Adminer 4.6.3 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `Academic`;
CREATE TABLE `Academic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `degree` varchar(300) NOT NULL,
  `institute` varchar(300) NOT NULL,
  `date` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `Academic` (`id`, `user_id`, `degree`, `institute`, `date`) VALUES
(1,	2,	'BCS',	'AWKUM',	'2016'),
(2,	2,	'HSSC',	'KMC',	'2012'),
(3,	2,	'Matric',	'mps',	'2010'),
(4,	3,	'BS Software Engineering',	'Islamic Internationl University ISB.',	'2018'),
(6,	3,	'HSSC',	'Quaid Azam groups of collages swabi.	',	'2013'),
(7,	3,	'Matric',	'Quaid Azam groups of collages swabi.',	'2011');

DROP TABLE IF EXISTS `applications`;
CREATE TABLE `applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `applications` (`id`, `post_id`, `applicant_id`) VALUES
(1,	2,	2),
(2,	2,	3),
(3,	4,	4),
(4,	4,	3);

DROP TABLE IF EXISTS `company`;
CREATE TABLE `company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `company` (`id`, `name`, `email`, `password`) VALUES
(1,	'EmmZee Communications',	'Emmzee@gmail.com',	'123456'),
(2,	'Rustum Soft Tech',	'rustum@gmail.com',	'123456');

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `category` varchar(255) NOT NULL,
  `location` varchar(225) NOT NULL,
  `status` varchar(100) NOT NULL,
  `salary` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `experience` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `jobs` (`id`, `cid`, `title`, `description`, `category`, `location`, `status`, `salary`, `time`, `experience`) VALUES
(2,	1,	'web Development',	'we need a web develpoer which has the ablity to make work in team and alone on one or more project asame time .must know about jquery , database management, strong command on php.',	'Web Development',	'Islamabad',	'permanent',	'30000-35000',	'morning',	'2 Years'),
(4,	1,	'Graphics Designer Job',	'We need a Graphics designer ,with new and unique ideas. who can create plagiarism free designs.and creating and beautiful animations .',	'Graphics Designer',	'Islamabad',	'permanent',	'20000-30000',	'morning',	'2 Years'),
(7,	1,	'IOS developer',	'we need a apple mobile app developer .which can make a new ideas and logical work .',	'IOS Apps Development',	'Islamabad',	'permanent',	'30000-40000',	'morning',	'2 Years'),
(8,	2,	'Unity Developer Needed',	'your Company needed a unity developer ,which has 2 years experience in programming , and have good skills in error detuction.',	'Unity Development',	'Lahore',	'permanent',	'30000-35000',	'morning',	'2 Years'),
(9,	1,	'Security Guard Needed',	'Security Guard Needed as full time ,we are looking for a responsible person having already experience in security duty.',	'Others',	'Islamabad',	'permanent',	'25000-35000',	'Night time',	'2 Years');

DROP TABLE IF EXISTS `relevant_qualifications`;
CREATE TABLE `relevant_qualifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `relevant_qualifications` (`id`, `user_id`, `qualification`) VALUES
(2,	2,	'php'),
(4,	2,	'.net'),
(13,	2,	'HTML 5'),
(14,	3,	'Photoshop'),
(15,	3,	'PHP'),
(16,	3,	'HTML'),
(17,	3,	'Java script');

DROP TABLE IF EXISTS `skills`;
CREATE TABLE `skills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `skills` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `skills` (`id`, `user_id`, `skills`) VALUES
(3,	2,	'football'),
(4,	2,	'Athletes'),
(5,	3,	'Marketing '),
(6,	3,	'Management');

DROP TABLE IF EXISTS `technical_skills`;
CREATE TABLE `technical_skills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `technical skill` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `technical_skills` (`id`, `user_id`, `technical skill`) VALUES
(2,	2,	'MS office'),
(3,	3,	'MS Office'),
(4,	3,	'Good typing Speed');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `phone_no` varchar(15) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `name`, `email`, `password`, `phone_no`, `address`) VALUES
(2,	'yousaf shah',	'yousafshah50@gmail.com',	'123456',	'3159553949',	'Village & P/O Mandani ,Tehsile Tangi ,District Charsadda.'),
(3,	'rabia basri',	'rabi@gmail.com',	'123456',	'3159553942',	'villege and P/O Swabi Tehsile Tangi District Swabi'),
(4,	'JAMIL AHMAD',	'jamil@gmail.com',	'123456',	'21321',	'villege and P/O Mandani Tehsile Tangi District Charsadda');

DROP TABLE IF EXISTS `Work_Details`;
CREATE TABLE `Work_Details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `position` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `Work_Details` (`id`, `user_id`, `position`, `company`, `start_date`, `end_date`) VALUES
(4,	2,	'Web develpor',	'Rustum soft',	'2016',	'2017'),
(5,	2,	'Web developer',	'Emmzee Communications',	'2017',	'2018'),
(7,	3,	'Web developer as internee',	'Emmzee Communication',	'2018',	'2018');

-- 2019-01-24 08:37:04
