<?php
session_start();
include 'include/con.php';
$sql="select users.id,name from users LEFT JOIN applications ON users.id=applications.applicant_id where post_id=".$_POST['id'];
  $result=mysqli_query($con,$sql);
  $num=mysqli_num_rows($result);
  if ($num>0) {
  	foreach ($result as $key) {  ?>
  	<a href="templates\profile.php?id=<?php  echo $key['id']; ?>" class="btn btn-success" title="See <?php  echo $key['name']; ?> resume"><?php  echo $key['name']; ?></a>
  <?php }
  }else{
  	echo '<h3 style="color:white">No Applications Submited Yet!</h3>';
  }
   

?>