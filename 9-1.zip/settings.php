<?php

/* Google App Client Id */
define('CLIENT_ID', 'xxxxxxxxxxxxxxxxxxxxxxxx');

/* Google App Client Secret */
define('CLIENT_SECRET', 'xxxxxxxxxxxxxxxxxxxxxxxx');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'xxxxxxxxxxxxxxxxxxxxxxxx');

?>