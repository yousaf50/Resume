<?php
session_start();
include '../include/conn.php';
if (isset($_SESSION['userid'])) {
	$userid=$_SESSION['userid'];
}else{
    $userid=$_GET['id'];
}
$sql="select * from users where id=".$userid;
    $result=mysqli_query($con,$sql); 
    $row=mysqli_fetch_array($result);
     function select($name,$con,$userid) {
         $sql="select * from ".$name." where user_id=".$userid;
            $result=mysqli_query($con,$sql);
            return $result;
         }
?>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.debug.js"></script>
	<script src="../js/jspdf.min.js"></script>
	<script src="../js/html2canvas.min.js"></script>
	<script src="../js/html2pdf.js"></script>
	<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
	 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<title><?php echo ucwords($row['name']); ?> Resume</title>
	<meta name="robots" content="noindex, nofollow">
	
	<script type="text/javascript" src="../js/getData.js"></script>
</head>
<body>
	
	<div id="resume2">
	<h1><?php echo ucwords($row['name']); ?></h1>
	<div id="address">
		<div>
			<h3>Local Address</h3>
			<?php echo ucwords($row['address']); ?>
		</div>
		<div id="first">
			<h3>Contact</h3>
			<?php echo "+92-".ucwords($row['phone_no']); ?>

			<?php echo ucwords($row['email']); ?>
		</div>
		<div>
			<h3>Permanent Address</h3>
			<?php echo ucwords($row['address']); ?>
		</div>
	</div>
	
	<h2>Relevant Qualifications</h2>
	<ul>
	  <?php
         $result2=select('relevant_qualifications',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<li>".$key['qualification']."</li>";
         }
      ?>      
	</ul>
	
	
	<h2>Work Experience</h2>
	 <?php
         $result2=select('Work_Details',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<span class='date'>".$key['start_date']." to ".$key['end_date']."</span><h3>".$key['position']."</h3><address>".$key['company']."</address>";
         }
      ?>


	<h2>Interest / Skills</h2>
	<h3>Personal Skills</h3>
	<ul>
		<?php
         $result2=select('skills',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<li>".$key['skills']."</li>";
         }
        ?> 
	</ul>
	<h3>Professional Skills</h3>
	<ul>
		<?php
         $result2=select('technical_skills',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<li>".$key['technical skill']."</li>";
         }
        ?>
	</ul>


	<h2>Education</h2>
	<?php
         $result2=select('Academic',$con,$userid);
          foreach ($result2 as $key) {
         	echo "<span class='date'>".$key['date']."</span><h3>".$key['degree']."</h3><address>".$key['institute']."</address>";
         }
      ?>
	</div>
	<hr style="border: 1px solid #A2AEBB; margin-right: 10%" />
	<button class="buttom" onclick="convert2pdf()" type="button" style="position: relative; float: right; margin-right: 10%">Download Resume</button><br><br>
	<script type="text/javascript">
        function convert2pdf() {
            var element = document.getElementById("resume2");
            html2pdf(element, {margin: 5});
        }
	</script>
	<style type="text/css" media="all">
		html{
			background-color:#FFF;
			padding:0 1em;
			}
		body {
			background-color:#FFF;
			font-family:Georgia, "Times New Roman", Times, serif;
			padding:1em;
			border:solid #AAA 1px;
			margin:1em auto;
			max-width: 50em;
			}
		#address{
			height:5em;
			width:48em;
			text-align:center;
			}
		#address div{
			width:14em;
			float:left;
			padding:0 .5em 0 1.5em;
			}
		#address h3{
			border-bottom: none;
			margin-top: 0;
			}	
		.date {
			float:right;
			font-size:.8em;
			margin-top:.4em;
			text-align:right;
			}
		abbr, acronym{
			border-bottom:1px dotted #333;
			cursor:help;
			}	
		address{
			font-style:italic;
			color:#333;
			font-size:.9em;
			}
			
		
		h1{
			font-size:1.75em;
			text-align:center;
			padding:.5em 0;
			}
		h2 {
			clear:both;
			font-size: 1.4em;
			font-weight:bold;
			margin-top:2em;
			font-variant: small-caps;
			padding-left:.25em;
			background-color:#EEE;
			border-bottom: 1px solid #999;
			letter-spacing: .06em;
			}
		h3 {margin: 1em 0 0 0;}
	</style>
	<style type="text/css" media="print">
		body {
			background-color:#FFF;
			border-width:0 0 0 0;
			margin:0;
			width:100%
			}
	</style>
</body></html>