<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script type="text/javascript" src="../js/getcl.js"></script>
    <script src="../js/jspdf.min.js"></script>
    <script src="../js/html2canvas.min.js"></script>
    <script src="../js/html2pdf.js"></script>
</head>
<body>
<div id="content">

<center><h1><?php echo $_POST['name']; ?></h1>
    <h4><?php echo $_POST['email']; ?><br>
     <?php echo $_POST['phone']; ?><br>
     <?php echo $_POST['address']; ?> </h4></center>

<h5 style="margin-left:100px"> 
    <?php 
     $year=substr($_POST['date'],0,4);
     $mounth=substr($_POST['date'],5,2);
     $day=substr($_POST['date'],8,2);
     $monthName = date("F", strtotime($mounth));
echo $monthName." ".$day.",".$year;?> </h5>

<h2 style="margin-left:100px"><?php echo $_POST['cname']; ?></h2>
<h4 style="margin-left:100px"><?php echo $_POST['ctitle']; ?><br>
<?php echo $_POST['ggcOrg']; ?>  
 <br>
<?php echo $_POST['ggcAddress']; ?> 
</h4><p style="margin-left:100px">
<?php echo $_POST['ggSel1']; ?> 
</p>
<p style="margin-left:100px"> <?php echo $_POST['ggStart']; ?>  
<br><br>   
<?php echo $_POST['ggMid']; ?>
<br><br> <?php echo $_POST['ggEnd']; ?></p>

<h4 style="margin-left:100px"><?php echo $_POST['ggSel2']; ?>,<br><?php echo $_POST['name']; ?> </h4>

</div>
<div id="editor"></div>
<button onclick="convert2pdf()" id="cmd">generate PDF</button>
<script type="text/javascript">
    function convert2pdf() {
        var element = document.getElementById("content");
        html2pdf(element, {margin: 5});
    }
</script>
</body>
</html>