<?php 
session_start();
include 'include/header.php';
?>

<body style="font-family:Sansation Light">
<script src="include/sweetalert.js"></script>
<?php  if(isset($_GET['msg']) && $_GET['msg']=='inserted'){ ?>
<script type="text/javascript">
swal("Good job!", "Sign Up Successfully!", "success");
</script>
<?php }elseif(isset($_GET['msg']) && $_GET['msg']=='login'){ ?>
<script type="text/javascript">
swal("Good job!", "LOGIN Successfully!", "success");
</script>
<?php }elseif(isset($_GET['msg']) && $_GET['msg']=='nologin'){ ?>
<script type="text/javascript">
swal("Ouch!", "Email OR Password is Wrong!", "error");
</script>
<?php }elseif (isset($_GET['msg'])) {  ?>
<script type="text/javascript">
   swal("Ouch!", "Try again!", "error");
</script>
<?php } ?>
    <div id="status"></div>

    <?php include 'include/nav.php'; ?>


    <section class="features">
        <div class="container">
            <div class="row">
                <div class="col-md-4" style="font-family:Sansation Light">
                    <h2>Post A Job</h2>
  <p><i class="fa fa-hand-o-right"></i><a href="all_jobs.php" style="color: white;"> All Jobs</a></p>
  <p><i class="fa fa-hand-o-right"></i><a href="applications.php" style="color: white;">Candidates applications</a></p>
                </div>
                <div class="col-md-8" style="font-family:Sansation Light">
<form method="POST" action="action.php">
  <div class="form-group row">
    <label class="col-sm-2 col-form-label">Job Title</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="title" required >
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Category</label>
    <div class="col-sm-10">
       <select class="form-control" name="cat">
    <option value="Web Development">Web Development</option>
    <option value="Web Desiging">Web Desiging</option>
    <option value="Graphics Designer">Graphics Designer</option>
    <option value="Unity Development">Unity Development</option>
    <option value="Andriod Apps Development">Andriod Apps Development</option>
    <option value="IOS Apps Development">IOS Apps Development</option>
    <option value="Desktop Development">Desktop Development</option>
    <option value="Others">Others</option>
       </select>
    </div>
  </div>
  <div class="form-group row">
    <label class="col-sm-2 col-form-label">Job Description</label>
    <div class="col-sm-10">
      <textarea class="form-control" name="description" required ></textarea>
    </div>
  </div>
  <div class="form-group row">
    <label class="col-sm-2 col-form-label">Job Location</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" name="location" required > 
    </div>
  </div>
  <div class="form-group row">
    <label class="col-sm-2 col-form-label">Job Status</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" name="status" required > 
    </div>
  </div>
   <div class="form-group row">
    <label class="col-sm-2 col-form-label">Salary Range</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" name="salary" required > 
    </div>
  </div>
   <div class="form-group row">
    <label class="col-sm-2 col-form-label">Time Shift</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" name="time" required > 
    </div>
  </div>
  <div class="form-group row">
    <label class="col-sm-2 col-form-label">Experience Required</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" name="exp" required > 
    </div>
  </div>
  <div class="form-group row">
    <button type="submit" class="btn btn-success">POST JOB</button>
  </div>
  <input type="hidden" name="post_job">
</form>
                </div>
            </div>
        </div>
    </section>
    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <h5><a href="index.html"> Go Resume</a></h5>
                </div>
                <div class="col-sm-6 social-icons"><a href="https://www.facebook.com/Go-Resume-1813690295611919/" target="_blank"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-instagram"></i></a></div>
            </div>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
