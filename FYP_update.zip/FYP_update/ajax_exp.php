<?php
session_start();
include 'include/conn.php';
$_POST["table"]='Work_Details';
if (isset($_POST['position'])) {

$sql='insert into '.$_POST["table"].' VALUES (NULL,'.$_SESSION["userid"].', "'.$_POST["position"].'", "'.$_POST["org"].'", "'.$_POST["start"].'", "'.$_POST["end"].'")';
$result=mysqli_query($con,$sql);
}
elseif (isset($_POST['delete'])) {
$sql="DELETE FROM ".$_POST['table']."
WHERE `id` = ".$_POST['delete'];
$result=mysqli_query($con,$sql);
}
$sql="select * from ".$_POST['table']." where user_id=".$_SESSION['userid'];
   $result=mysqli_query($con,$sql); $i=1;
            while ($row=mysqli_fetch_array($result)) {
                echo "<tr><td>".$row['2']."</td><td>".$row['3']."</td><td>".$row['4']."</td><td>".$row['5']."</td>"; ?> 
  <td><a href='javascript:0;' onclick='delet3("Work_Details",<?php echo $row['id']; ?>)' ><i class='fa fa-trash' ></a></td></tr>
                <?php $i++;
             } 



?>