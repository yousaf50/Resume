<script type="text/javascript">
      function signu() {
        $('#myModal2').modal().hide();
        $('#myModal').modal('toggle');
      }
      
    </script>
<nav class="navbar navbar-inverse">
    <div class="container" style="font-family:Sansation Light">
           
<?php if (isset($_SESSION['cid'])) {
  echo '<div class="navbar-header"><a class="navbar-brand navbar-link" href="jobs_post.php">⚡ '.$_SESSION['cname'].'</a>
            </div>';
    echo '<a class="btn btn-success navbar-btn navbar-right"
                            role="button" href="action.php?logout=ok" />Log Out</a>';
    echo "<a class='btn btn-primary navbar-btn navbar-right'href='jobs_post.php' >Hello ".$_SESSION['cname']."</a>";
}elseif(isset($_SESSION['userid'])){
echo '<div class="navbar-header"><a class="navbar-brand navbar-link" href="index.php">⚡ Explore Jobs</a>
            </div>';
  echo '<a class="btn btn-success navbar-btn navbar-right"
   role="button" href="action.php?logout=ok" />Log Out</a>';
   echo "<a class='btn btn-primary navbar-btn navbar-right'href='builder.php' >Update Your Resume</a>";
}else{ 
   echo '<div class="navbar-header"><a class="navbar-brand navbar-link" href="index.php">⚡ Explore Jobs</a>
            </div>'; ?>
<?php } ?>     
 <!-- Modal content-->                       
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Sign Up Your Comapny Or Organization</h4>
        </div>
<form class="form-horizontal" action="action.php" method="POST">
        <div class="modal-body">
    <div class="form-group">
    <label  class="col-sm-2 control-label">Organization Name</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="name" placeholder="Comapny Name" required>
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10">
      <input type="email" class="form-control" name="email" placeholder="Your Email" required>
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" name="password" placeholder="Password" required>
    </div>
  </div>
         
        </div>
        <div class="modal-footer">
             <input type="hidden" name="company_signup">
<button type="submit"  class="btn btn-info">Sign Up</button>
<button type="button" class="btn btn-default" onClick="document.location.reload(true)" >Close</button>        </div>
</form>

      </div>
      
    </div>
  </div>
  <!-- modal end -->
  <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
     <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Login As Company Account</h4>
        </div>
<form class="form-horizontal" action="action.php" method="POST" >
<div class="modal-body">
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Comapny Email</label>
    <div class="col-sm-10">
      <input type="email" class="form-control" name="email" placeholder="Your Email" required>
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" name="password" placeholder="Password" required>
    </div>
  </div>
  <hr>
  <center><p>New Company <a href="#" onclick="signu();"  > Signup here !</a></p></center>
        </div>
        <div class="modal-footer">
<input type="hidden" name="company_login">
<button type="submit"  class="btn btn-info">LOG IN</button>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>        </div>
</form>

      </div>
      
    </div>
  </div>
  <!-- modal end -->
</div>

                <ul class="nav navbar-nav navbar-right"></ul>
            </div>
        </div>
    </nav>
    