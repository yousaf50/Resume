<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title class="ion-ios-briefcase-outline">Go Resume</title>
    <meta name="description" content="A free app for building resumes and exploring jobs" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="generator" content="Codeply">
    <link rel="stylesheet" href="./css/bootstrap.min.css" />
    <link rel="stylesheet" href="./css/animate.min.css" />
    <link rel="stylesheet" href="./css/ionicons.min.css" />
    <link rel="stylesheet" href="./css/styles.css" />
  </head>
  <body>
    <nav id="topNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="#first"><i class="ion-document-text"></i> Go Resume</a>
            </div>
            <div class="navbar-collapse collapse" id="bs-navbar">
                <ul class="nav navbar-nav">
                    <li>
                        <a class="page-scroll" href="#first">Home</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#three">Job Board</a>
                    </li>
                    
                    <li>
                        <a class="page-scroll" href="#four">Features</a>
                    </li>
                     <li>
                        <a  data-toggle="modal" href="#aboutModal">About</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#last">Contact</a>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li style="margin-left: 40px;margin-right: -30px;">
                        <a  onclick="login();" href="#">LOGIN /</a>
                    </li>
                    <li>
                        <a onclick="sign_up();" href="#" >Sign Up </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav><script src="include/sweetalert.js"></script>
    <script type="text/javascript">
        function login(){
    swal("LOGIN To The System As", {
  buttons: {
    cancel: "LOGIN AS Student!",
    catch: {
      text: "LOGIN AS Company!",
      value: "catch",
    },
  },
})
.then((value) => {
  switch (value) {
    case "catch":
    $('#myModal2').modal('toggle');
      break;
    default:
      $('#myModal3').modal('toggle');
  }
});
        }
        function sign_up(){
    swal("Registration As", {
  buttons: {
    cancel: "Company Registration!",
    catch: {
      text: "Student Registration!",
      value: "catch",
    },
  },
})
.then((value) => {
  switch (value) {
    case "catch":
    $('#myModal4').modal('toggle');
      break;
    default:
      $('#myModal5').modal('toggle');
  }
});
        }
        function new_company() {
             $('#myModal5').modal('toggle');
        }
    </script>
    <header id="first">
        <div class="header-content">
            <div class="inner">
                <h1 class="cursive">Online App for building Resume & exploring Jobs</h1>
                <h4>Select One</h4>
                <hr>
    <a  href="jobs.php"  class="btn btn-primary btn-xl page-scroll" >Explore Jobs</a> &nbsp; <a data-toggle="modal" href="#myModal3" class="btn btn-primary btn-xl page-scroll">Build Resumes</a>
            </div>
        </div>
       
    </header>
    <script src="include/sweetalert.js"></script>
<?php  if(isset($_GET['msg']) && $_GET['msg']=='inserted'){ ?>
<script type="text/javascript">
swal("Student Registration Successfully!", "", "success");
</script>
<?php }elseif(isset($_GET['msg']) && $_GET['msg']=='company_inserted'){ ?>
<script type="text/javascript">
swal("Company Registration Successfully!", "", "success");
</script>
<?php }elseif(isset($_GET['msg']) && $_GET['msg']=='login'){ ?>
<script type="text/javascript">
swal("Good job!", "LOGIN Successfully!", "success");
</script>
<?php }elseif(isset($_GET['msg']) && $_GET['msg']=='nologin'){ ?>
<script type="text/javascript">
swal("Ouch!", "Email OR Password is Wrong!", "error");
</script>
<?php }elseif (isset($_GET['msg'])) {  ?>
<script type="text/javascript">
   swal("Ouch!", "Try again!", "error");
</script>
<?php } ?>
  <center> <h2>Jobs Bank!</h2></center>
    <section id="three" class="no-padding">
        <div class="container-fluid">
            <div class="row no-gutter">
                <div class="col-lg-4 col-sm-6">
<a href="jobs.php" class="gallery-box"  data-src="./assets/deer.jpg">
<img src="./assets/all.jpg" class="img-responsive" alt="Image 1" style="height: 285px;">
<div class="gallery-box-caption">
<div class="gallery-box-content">
                                <div>
    <i class="icon-lg ion-ios-search"></i>
    <h3>ALL JOBS!</h3>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
    <a href="http://localhost/FYP/jobs.php?categiory=Web%20Development" class="gallery-box" data-src="./assets/beach.jpg">
             <img src="./assets/web2.jpg" class="img-responsive" alt="Image 2" style="height: 285px;">
                        <div class="gallery-box-caption">
                            <div class="gallery-box-content">
                                <div>
        <i class="icon-lg ion-ios-search"></i>
        <h3>Web Development Jobs!</h3>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
				<div class="clearfix hidden-lg"> </div>
                <div class="col-lg-4 col-sm-6">
<a href="http://localhost/FYP/jobs.php?categiory=Web%20Desiging" class="gallery-box"  data-src="./assets/lake.jpg">
 <img src="./assets/design.png" class="img-responsive" alt="Image 3" style="height: 285px;">
                        <div class="gallery-box-caption">
                            <div class="gallery-box-content">
                                <div>
        <i class="icon-lg ion-ios-search"></i>
        <h3>Web Desiging Jobs!</h3>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
<a href="http://localhost/FYP/jobs.php?categiory=Andriod%20Apps%20Development" class="gallery-box"  data-src="./assets/bike.jpg">
        <img src="./assets/apps.jpg" class="img-responsive" alt="Image 4" style="height: 285px;">
                        <div class="gallery-box-caption">
                            <div class="gallery-box-content">
                                <div>
       <i class="icon-lg ion-ios-search"></i>
       <h3>Andriod Apps Development Jobs!</h3>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
				<div class="clearfix hidden-lg"> </div>
                <div class="col-lg-4 col-sm-6">
<a href="http://localhost/FYP/jobs.php?categiory=Unity%20Development" class="gallery-box" data-src="./assets/city.jpg">
        <img src="./assets/unity2.png" class="img-responsive" alt="Image 5" style="height: 285px;">
                        <div class="gallery-box-caption">
                            <div class="gallery-box-content">
                                <div>
                                    <i class="icon-lg ion-ios-search"></i>
                    <h3>Games Development Jobs!</h3>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
 <a href="http://localhost/FYP/jobs.php?categiory=Graphics%20Designer" class="gallery-box" data-src="./assets/colors.jpg">
                        <img src="./assets/graphics.jpg" class="img-responsive" alt="Image 6" style="height: 285px;">
                        <div class="gallery-box-caption">
                            <div class="gallery-box-content">
                                <div>
           <i class="icon-lg ion-ios-search"></i>
           <h3>Graphics Designer Jobs!</h3>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <section class="container-fluid" id="four">
        <div class="row">
            <div class="col-xs-10 col-xs-offset-1 col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
                <h2 class="text-center text-primary">Features</h2>
                <hr>
                <div class="media wow fadeInRight">
                    <h3>Make Resume!</h3>
                    <div class="media-body media-middle">
                        <p>You can easly make your resume here? just enter your information.than select a design of how your resume look like.Done!</p>
                    </div>
                    <div class="media-right">
                        <i class="icon-lg ion-ios-bolt-outline"></i>
                    </div>
                </div>
                <hr>
                <div class="media wow fadeIn">
                    <h3>Download!</h3>
                    <div class="media-left">
                        <a href="#alertModal" data-toggle="modal" data-target="#alertModal"><i class="icon-lg ion-ios-cloud-download-outline"></i></a>
                    </div>
                    <div class="media-body media-middle">
                        <p>Yes, please. donwload your resume.</p>
                    </div>
                </div>
                <hr>
                <div class="media wow fadeInRight">
                    <h3>jobs Advertisement!</h3>
                    <div class="media-body media-middle">
                        <p>Organization, Company or institute are wellcome to advertise his post here.</p>
                    </div>
                    <div class="media-right">
                        <i class="icon-lg ion-ios-snowy"></i>
                    </div>
                </div>
                <hr>
                <div class="media wow fadeIn">
                    <h3>Job Board</h3>
                    <div class="media-left">
                        <i class="icon-lg ion-ios-heart-outline"></i>
                    </div>
                    <div class="media-body media-middle">
                        <p>Choose what you like,search job for you what's you want.</p>
                    </div>
                </div>
                <hr>
            </div>
        </div>
    </section>
    <aside class="bg-dark">
        <div class="container text-center">
            <div class="call-to-action">
                <h2 class="text-primary">Get Started</h2>
        <a data-toggle="modal" href="#myModal3"  class="btn btn-default btn-lg wow flipInX">Free Download Your Resume</a>
            </div>
            <br>
            
        </div>
    </aside>
    <section id="last">
        <div class="container">
            <div class="row">
            <div class="col-lg-8 col-lg-offset-2 text-center">
                    <h2 class="margin-top-0 wow fadeIn">Get in Touch</h2>
                    <hr class="primary">
                    <p>We love feedback. Fill out the form below and we'll get back to you as soon as possible.</p>
                </div>
        <div class="col-lg-10 col-lg-offset-1 text-center">
            <form class="contact-form row">
                        <div class="col-md-4">
                            <label></label>
                            <input type="text" class="form-control" placeholder="Name">
                        </div>
                        <div class="col-md-4">
                            <label></label>
                            <input type="text" class="form-control" placeholder="Email">
                        </div>
                        <div class="col-md-4">
                            <label></label>
                            <input type="text" class="form-control" placeholder="Phone">
                        </div>
                        <div class="col-md-12">
                            <label></label>
                            <textarea class="form-control" rows="9" placeholder="Your message here.."></textarea>
                        </div>
                        <div class="col-md-4 col-md-offset-4">
                            <label></label>
    <button type="button" onclick="mail();" class="btn btn-primary btn-block btn-lg">Send <i class="ion-android-arrow-forward"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
     <script src="include/sweetalert.js"></script>
    <script type="text/javascript">
        function mail() {
swal("Email Info!", "Sorry We Can't Deliver your Mail Due to Local Server!");
        }
    </script>
    <footer id="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-6 col-sm-3 column">
                     <a class="page-scroll" href="#first" style="color: white;"><h4>Go Resume</h4></a>
                 </div>
                <div class="col-xs-6 col-sm-3 column">
    <a class="page-scroll" data-toggle="modal"  href="#aboutModal" style="color: white;"> <h4>About Us</h4></a>
                 </div>
                <div class="col-xs-12 col-sm-3 column">
                   <a href="jobs.php" style="color: white;"> <h4>Search Job</h4></a>
                    
                </div>
                <div class="col-xs-12 col-sm-3 text-right">
                   
                    <ul class="list-inline">
                        <li> <h4>Follow Us</h4></li>
    <li><a rel="nofollow" href="" title="Twitter" style="color: white;"><i class=" ion-social-twitter-outline"></i></a>&nbsp;</li>
                      <li><a rel="nofollow" href="https://www.facebook.com/" target="_BLANK"  title="Facebook" style="color: white;"><i class=" ion-social-facebook-outline"></i></a>&nbsp;</li>
                      <li><a rel="nofollow" href="" title="Dribble" style="color: white;"><i class="ion-social-dribbble-outline"></i></a></li>
                    </ul>
                </div>
            </div>
           
           
        </div>
    </footer>
    <div id="galleryModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
        <div class="modal-content">
        	<div class="modal-body">
        		<img src="" id="galleryImage" class="img-responsive" />
        		<p>
        		    <br/>
        		    <button class="btn btn-primary btn-lg center-block" data-dismiss="modal" aria-hidden="true">Close <i class="ion-android-close"></i></button>
        		</p>
        	</div>
        </div>
        </div>
    </div>
    <div id="aboutModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content">
        	<div class="modal-body">
        		<h2 class="text-center">Well Come to Go Rresume!</h2>
        		<h5 class="text-center">
        		    Go Resume is a non-profite system for CV maker & Jobs Bank. 
        		</h5>
        		<p class="text-justify">
        		   Create unlimited resumes, Download & share them. Explore for jobs , also facilty for user login , signup & as will as for company , organization Or institute.
                   People can here search jobs and apply for then.  
        		</p>
        		
        		<br/>
        		<button class="btn btn-primary btn-lg center-block" data-dismiss="modal" aria-hidden="true"> OK </button>
        	</div>
        </div>
        </div>
    </div>
    
    <!--scripts loaded here -->
    <script src="./js/jquery.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
    <script src="./js/jquery.easing.min.js"></script>
    <script src="./js/wow.js"></script>
    <script src="./js/scripts.js"></script>
  </body>
</html>


<div class="modal fade" id="myModal3" role="dialog">
    <div class="modal-dialog">
     <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Login Go Resume</h4>
        </div>
<form class="form-horizontal" action="action.php" method="POST" >
<div class="modal-body">

  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Student Email</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="email" placeholder="Student Email" pattern="^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$" title="Please Enter Email Address" required>
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" name="password" placeholder="Password" required>
    </div>
  </div>
         
        </div>
        <div class="modal-footer">
            <input type="hidden" name="login">
<button type="submit"  class="btn btn-info">LOG IN</button>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>        </div>
</form>

      </div>
      
    </div>
  </div>
  <!-- modal end -->
  <!-- modal end -->
  <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
     <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Company Login</h4>
        </div>
<form class="form-horizontal" action="action.php" method="POST" >
<div class="modal-body">
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Comapny Email</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="email" placeholder="Company Email" pattern="^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$" title="Please Enter Email Address" required>
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" name="password" placeholder="Password" required>
    </div>
  </div>
  <hr>
  <center><p>New Company <a href="#" onclick="new_company();"  > Signup here !</a></p></center>
        </div>
        <div class="modal-footer">
<input type="hidden" name="company_login">
<button type="submit"  class="btn btn-info">LOG IN</button>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>        </div>
</form>

      </div>
      
    </div>
  </div>
  <!-- modal end -->
  <!-- Modal content-->                       
<div class="modal fade" id="myModal5" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Register Your Comapny Or Organization</h4>
        </div>
<form class="form-horizontal" action="action.php" method="POST">
        <div class="modal-body">
    <div class="form-group">
    <label  class="col-sm-2 control-label">Company Name</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="name" placeholder="Comapny Name" required>
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Company Email</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="email" placeholder="Company Email" pattern="^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$" title="Please Enter Email Address" required>
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Company Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" name="password" placeholder="Company Password" required>
    </div>
  </div>
         
        </div>
        <div class="modal-footer">
             <input type="hidden" name="company_signup">
<button type="submit"  class="btn btn-info">Register Company</button>
<button type="button" class="btn btn-default" onClick="document.location.reload(true)" >Close</button>        </div>
</form>

      </div>
      
    </div>
  </div>
  <!-- modal end -->
  <div class="modal fade" id="myModal4" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Student Registration to Go Resume</h4>
        </div>
<form class="form-horizontal" action="action.php" method="POST" name="signup">

        <div class="modal-body">

    <div class="form-group">
    <label  class="col-sm-2 control-label">Student Name</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="signupname" placeholder="Student Name" required>
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Student Email</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="email" placeholder="Student Email" pattern="^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$" title="Please Enter Email Address" required>
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" name="password" placeholder="Password" required>
    </div>
  </div>
         
        </div>
        <div class="modal-footer">
             <input type="hidden" name="signup">
<button type="submit"  class="btn btn-info">Sign Up</button>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>        </div>
</form>

      </div>
      
    </div>
  </div>
  <!-- modal end -->