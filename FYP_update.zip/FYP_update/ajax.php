<?php
session_start();
include 'include/conn.php';
if (isset($_POST['data'])) {
$output='';
$sql='insert into '.$_POST["table"].' VALUES (NULL,'.$_SESSION["userid"].', "'.$_POST["data"].'");';
$result=mysqli_query($con,$sql);
}
elseif (isset($_POST['delete'])) {
$sql="DELETE FROM ".$_POST['table']."
WHERE `id` = ".$_POST['delete'];
$result=mysqli_query($con,$sql);
}
$sql="select * from ".$_POST['table']." where user_id=".$_SESSION['userid'];
    $result=mysqli_query($con,$sql); $i=1;
    while ($row=mysqli_fetch_array($result)) {
      echo "<tr><td>".$i."</td><td>".$row[2]."</td>"; ?> 
    <td><a href='javascript:0;' onclick='delet("<?php echo $_POST['table']; ?>",<?php echo $row['id']; ?>)' ><i class='fa fa-trash' ></a></td></tr>
 <?php $i++;
             }



?>