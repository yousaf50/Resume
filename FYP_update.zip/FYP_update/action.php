<?php
session_start();
include 'include/conn.php';
if (isset($_POST['apply_id'])) {
	$sql="select * from applications where post_id=".$_POST['apply_id']." && applicant_id=".$_SESSION['userid'];
	$result=mysqli_query($con,$sql);
	if (mysqli_num_rows($result)>0) {
		echo "you already apply for this post";
	}else{
       $sql="select * from Academic where user_id=".$_SESSION['userid'];
      $result=mysqli_query($con,$sql);
      if (mysqli_num_rows($result)>0) {
      	 $sql="insert into applications (post_id,applicant_id) values(".$_POST['apply_id'].",".$_SESSION['userid'].")";
	     $result2=mysqli_query($con,$sql);
	     if ($result2) {
	 	  echo "1";
	    }
      }else{
echo "Please Update your Resume 1st, for apply any post!";
      }	
	}
	die();
}
elseif ($_GET['did']) {
	$sql="delete from jobs where id=".$_GET['did']." && cid=".$_SESSION['cid'];
	$result=mysqli_query($con,$sql);
	if ($result) {
	header('location:all_jobs.php?msg=delete');
    	exit();
	}else{
	header('location:all_jobs.php?msg=error');
    	exit();
	}
}
elseif(isset($_POST['job_edit'])){
$sql="update jobs set title='".$_POST['title']."',description='".$_POST['description']."',category='".$_POST['cat']."',location='".$_POST['location']."',status='".$_POST['status']."',salary='".$_POST['salary']."',time='".$_POST['time']."',experience='".$_POST['exp']."' where id=".$_POST['id'];
$result=mysqli_query($con,$sql);
if ($result) {
	header('location:all_jobs.php?msg=updated');
    	exit();
}else{
	header('location:all_jobs.php?msg=error');
    exit();
} 
}
elseif(isset($_POST['post_job'])){
   $sql="INSERT INTO `jobs` (`cid`, `title`, `description`, `category`, `location`, `status`, `salary`, `time`, `experience`)
VALUES (".$_SESSION['cid'].",'".$_POST['title']."','".$_POST['description']."','".$_POST['cat']."','".$_POST['location']."','".$_POST['status']."','".$_POST['salary']."','".$_POST['time']."','".$_POST['exp']."')";
$result=mysqli_query($con,$sql);
if ($result) {
	header('location:all_jobs.php?msg=inserted');
    	exit();
}else{
	header('location:jobs_post.php?msg=error');
    exit();
}    
}
	elseif (isset($_POST['company_login'])) {
    $sql="select * from company where email='".$_POST['email']."' && password='".$_POST['password']."'";
	$result=mysqli_query($con,$sql);
	$num=mysqli_num_rows($result);

if ($num>0) {
	$row=mysqli_fetch_array($result);
    $_SESSION['cname']=$row['name'];
	$_SESSION['cid']=$row['id'];
	header('location:jobs_post.php');
    	exit();
}else{
	header('location:index.php?msg=nologin');
    	exit();
}
}
elseif (isset($_POST['company_signup'])) {
	$sql="INSERT INTO `company` (`name`, `email`, `password`)VALUES ('".$_POST['name']."', '".$_POST['email']."', '".$_POST['password']."')";
$result=mysqli_query($con,$sql);
if ($result) {
	header('location:index.php?msg=company_inserted');
    	exit();
}else{
	header('location:index.php?msg=error');
    	exit();
}
}
elseif (isset($_POST['signup'])) {
$sql="INSERT INTO `users` (`name`, `email`, `password`, `phone_no`, `address`)VALUES ('".$_POST['signupname']."', '".$_POST['email']."', '".$_POST['password']."','', '')";
$result=mysqli_query($con,$sql);
if ($result) {
	header('location:index.php?msg=inserted');
    	exit();
}else{
	header('location:index.php?msg=error');
    	exit();
}
}elseif (isset($_POST['login'])) {
	$sql="select * from users where email='".$_POST['email']."' && password='".$_POST['password']."'";
	$result=mysqli_query($con,$sql);
	 $num=mysqli_num_rows($result);
if ($num>0) {
	$row=mysqli_fetch_array($result);
    $_SESSION['name']=$row['name'];
	$_SESSION['userid']=$row['id'];
	if (isset($_POST['joblogin'])) {
	   header('location:jobs.php?msg=login');
	}else{
       header('location:builder.php?msg=login');
	}
    	exit();
}else{
	header('location:index.php?msg=nologin');
    	exit();
}
}
elseif (isset($_GET['logout'])) {
	session_destroy();
	header('location:index.php');
    	exit();
}elseif (isset($_POST['savedata'])) {
 $sql='UPDATE `users` SET
`name` = "'.$_POST["name"].'",
`email` = "'.$_POST["email"].'",
`phone_no` = "'.$_POST["phone"].'",
`address` = "'.$_POST["address"].'" 
WHERE `id` ='.$_SESSION["userid"];
$result=mysqli_query($con,$sql);
header('location:builder.php?msg=done');
    	exit();
}
else{
	echo "Ouch try again !";
}



?>