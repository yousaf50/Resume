<?php
session_start();
include 'include/conn.php';
$sql="select * from users where id=".$_SESSION['userid'];
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);
?>
<!DOCTYPE html>
<html>
<head>
<title>GoResume</title>
	<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7; IE=EmulateIE9">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
    <link rel="stylesheet" type="text/css" href="style.css" media="all" />
    <link rel="stylesheet" type="text/css" href="demo.css" media="all" />
    <link rel="stylesheet" type="text/css" href="css/snackbar.css" media="all" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/resume.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">


</head>
<header>

    <nav class="navbar">
        <div class="container" style="font-family:Sansation Light">
            <div class="navbar-header">
                <a class="navbar-brand navbar-link" href="#">⚡Well Come <?php echo $row['name']; ?></a>
            </div>
            <a class="btn btn-success navbar-btn navbar-right" role="button"<base href="jobs.php" />Explore Jobs</a>
            <a class="btn btn-primary navbar-btn navbar-right" role="button"  href="action.php?logout=ok" >LOGOUT</a>

        </div>
    </nav>



</header>
<body>
<div class="container">
    <header>

        <ul class="pagination">

            <li class="active"><a href="builder.php">Create Resume</a></li>
            <li><a href="coverLetter.html">Create Cover Letter</a></li>
            <!-- <li><a href="memo.html">Create Memo</a></li> -->

        </ul>​
        <h1>Create Your Resume</h1>

    </header>


<form action="action.php" method="POST">
      <div  class="form">
                    <!-- Modal -->
<div class="modal fade" id="tempSelectModal" role="dialog">
    <div class="modal-dialog">
  <!-- Modal content-->
<div class="modal-content" style="width: auto">
   <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Templates</h4>
             </div>
    <div class="modal-body" style="background-color: #F1F1F1">
    <div class="form-group">
    <div style="float: left">
    <img src="images/1.png" id="tmp1" style="width: 256px;height: 335.75px; padding: 2%"><br>
<button type="button" class="btn btn-primary" onclick="print(1);">Select Template</button>
<button type="button" class="btn btn-primary" onclick="viewTemp('images/1.png')">Preview Template</button>
<div id="snackbar1">Template Selected</div>
            </div>
            <script type="text/javascript">
                function print(page){
                window.open('templates/'+page+'.php','_SELF');
                    exit();
                }
            </script>
 <div style="float: right">
<img src="images/2.png" id="tmp2" style="width: 256px;height: 335.75px; padding: 2%"><br>
<button type="button" class="btn btn-primary" onclick="print(2);">Select Template</button>
             <button type="button" class="btn btn-primary" onclick="viewTemp('images/2.png')">Preview Template</button>
     <div id="snackbar2">Template Selected</div>
                                        </div>

                             <div style="float: left">
<img src="images/3.png" id="tmp3" style="width: 256px;height: 335.75px; padding: 2%"><br>
<button type="button" class="btn btn-primary" onclick="print(3);">Select Template</button>
    <button type="button" class="btn btn-primary" onclick="viewTemp('images/3.png')">Preview Template</button>
            <div id="snackbar3">Template Selected</div>
                                        </div>

                <div style="float: right">
     <img src="images/4.png" id="tmp4" style="width: 256px;height: 335.75px; padding: 2%"><br>
     <button type="button" class="btn btn-primary" onclick="print(4);" >Select Template</button>
    <button type="button" class="btn btn-primary" onclick="viewTemp('images/4.png')">Preview Template</button>
         <div id="snackbar4">Template Selected</div>
                                        </div>

                    <div style="float: left">
 <img src="images/5.png" id="tmp5" style="width: 256px;height: 335.75px; padding: 2%"><br>
<button type="button" class="btn btn-primary" onclick="print(5);"  >Select Template</button>
<button type="button" class="btn btn-primary" onclick="viewTemp('images/5.png')">Preview Template</button>
<div id="snackbar5">Template Selected</div>
                                        </div>
<div style="float: right">
<img src="images/6.png" id="tmp6" style="width: 256px;height: 335.75px; padding: 2%"><br>
<button type="button" class="btn btn-primary" onclick="print(6);">Select Template</button>
            <button type="button" class="btn btn-primary" onclick="viewTemp('images/6.png')">Preview Template</button>
                                            <!--<div id="snackbar12">Template Selected</div>-->
                                     </div>

                    <div style="float: left">
    <img src="images/7.png" id="tmp7" style="width: 256px;height: 335.75px; padding: 2%"><br>
    <button type="button" class="btn btn-primary" onclick="print(7);" >Select Template</button>
    <button type="button" class="btn btn-primary" onclick="viewTemp('images/7.png')">Preview Template</button>
                                            <!--<div id="snackbar13">Template Selected</div>-->
                                        </div>

                                    </div>
                                    <div class="modal-footer"></div>
                                </div>

                            </div> <!-- modal-content -->

                        </div> <!-- modal-dialog -->
                    </div>


<hr style="border: 1px solid #A2AEBB; margin-right: 10%" />​
    			<p class="contact"><label for="name">Full Name</label></p>
                <input type="hidden" name="savedata">
    <input id="name" name="name" placeholder="First and last name"  type="text" value="<?php echo $row['name']; ?>" required>

    			<p class="contact"><label for="email">Email Address</label></p>
    			<input id="email" name="email" placeholder="example@domain.com"  type="email" value="<?php echo $row['email']; ?>" required>
                
                <p class="contact"><label for="phone">Phone No.</label></p> 
    			<input id="phone" name="phone" placeholder="Phone No"  type="text" value="<?php echo $row['phone_no']; ?>" required>
    			 
                <p class="contact"><label for="address">Address</label></p>
    			<input type="text" id="address" name="address" placeholder="Address" value="<?php echo $row['address']; ?>" required>

            
<hr style="border: 1px solid #A2AEBB; margin-right: 10%" />​
                <p class="contact"><label>Mention relevant qualifications</label></p>
        <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#qualModal" style="position: relative; float: right; margin-right: 10%">Qualifications Summary</button><br><br>

                    <!-- Modal -->
<div class="modal fade" id="qualModal" role="dialog">
                        <div class="modal-dialog">

                            <!-- Modal content-->
<div class="modal-content">
<div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title">Summary of Qualifications</h4>
                                </div>
                     <div class="modal-body">
    <div class="form-group" id="qualInput">

<label for="qual">Add relevant Qualifications</label><br><br>
<input class="form-control inputName" id="relevant_qualifications" type="text" placeholder="Photoshop, MVC, .net, node.js etc..">
 </div>
 <button type="button" class="btn btn-primary" onclick="addqual('relevant_qualifications')">Add Qualification</button>
</div>
<div class="modal-footer">

<div id="snackbar6">Qualification Added</div>
<table class="table table-striped table-hover table-users">
<thead>
    <tr><td>Sno</td><td>Qualifications</td><td>Action</td></tr>
</thead>
        <tbody id="relevant_qualifications_table">
            <?php  $sql="select * from relevant_qualifications where user_id=".$_SESSION['userid'];
            $result=mysqli_query($con,$sql); $i=1;
            while ($row=mysqli_fetch_array($result)) {
                echo "<tr><td>".$i."</td><td>".$row['qualification']."</td>"; ?> 
    <td><a href='javascript:0;' onclick='delet("relevant_qualifications",<?php echo $row['id']; ?>)' ><i class='fa fa-trash' ></a></td></tr>
                <?php $i++;
             } ?>
            
        </tbody>
                                    </table>
                                </div>
                            </div> <!-- modal-content -->
                        </div> <!-- modal-dialog -->
                    </div>

<hr style="border: 1px solid #A2AEBB; margin-right: 10%" />​
                <p class="contact"><label>Provide Academic Details</label></p>
 <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#eduModal" style="position: relative; float: right; margin-right: 10%">Educational Details</button><br><br>
<div class="modal fade" id="eduModal" role="dialog">
    <div class="modal-dialog">
 <!-- Modal content-->
<div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
     <h4 class="modal-title">Educational Details</h4> </div>
     <div class="modal-body">
        <div class="form-group" id="eduInput">
            <label for="eduDegree">Degree</label><br><br>
<input class="form-control inputName" id="edu_degree" type="text">
<label for="eduSchool">Institute</label><br><br>
    <input class="form-control inputSchool" id="edu_institute" type="text">
<label for="eduGraduationDate">Graduated In</label><br><br>
    <input type="number" id="edu_date" min="1900" max="2099" step="1" value="2016" /><button type="button" class="btn btn-primary" onclick="add_edu();">ADD </button>
                                   </div>
                                </div>
     <div class="modal-footer">
     <table class="table table-striped table-hover table-users">
        <thead><tr>
            <td><strong>Degree</strong></td>
               <td><strong>Institute</strong></td>
                <td><strong>Graduated In</strong></td>
                <td><strong>Action</strong></td>
               </tr>
    </thead><tbody id="edu_table">
         <?php  $sql="select * from Academic where user_id=".$_SESSION['userid'];
            $result=mysqli_query($con,$sql); $i=1;
            while ($row=mysqli_fetch_array($result)) {
                echo "<tr><td>".$row['2']."</td><td>".$row['3']."</td><td>".$row['4']."</td>"; ?> 
    <td><a href='javascript:0;' onclick='delet2("Academic",<?php echo $row['id']; ?>)' ><i class='fa fa-trash' ></a></td></tr>
                <?php $i++;
             } ?>

    </tbody>
            
             </table>

                                </div>
                            </div> <!-- modal-content -->

                        </div> <!-- modal-dialog -->
                    </div>
 <hr style="border: 1px solid #A2AEBB; margin-right: 10%" />​
     <p class="contact"><label>Provide Work Details</label></p>
<button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#workModal" style="position: relative; float: right; margin-right: 10%">Work Details</button><br><br>

                    <!-- Modal -->
    <div class="modal fade" id="workModal" role="dialog">
         <div class="modal-dialog">
<div class="modal-content">
        <div class="modal-header">
   <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title">Work Details</h4>
         </div>
            <div class="modal-body">
             <div class="form-group" id="workInput">
     <label for="workPosition">Position</label><br><br>
<input class="form-control inputName" id="position" type="text" >
<label for="workOrg">Company or Organization</label><br><br>
<input class="form-control inputSchool" id="org" type="text" >
 <label for="workDurationStart">Started</label>
<input type="number" id="start" min="1900" max="2099" step="1" value="2016" />
<label for="workDurationEnd">Ended</label>
<input type="number" id="end" min="1900" max="2099" step="1" value="2016" />
                     </div>
                                </div>
    <div class="modal-footer">
    <button type="button" class="btn btn-primary" onclick="addexp();">ADD</button>
 <table class="table table-striped table-hover table-users">
        <thead>
        <tr>
        <td><strong>Position</strong></td>
        <td><strong>Organization</strong></td>
        <td><strong>Start</strong></td>
        <td><strong>End</strong></td>
        </tr>
        </thead>
        <tbody id="exp_table">
          <?php 
$sql="select * from Work_Details where user_id=".$_SESSION['userid'];
   $result=mysqli_query($con,$sql); $i=1;
            while ($row=mysqli_fetch_array($result)) {
                echo "<tr><td>".$row['2']."</td><td>".$row['3']."</td><td>".$row['4']."</td><td>".$row['5']."</td>"; ?> 
  <td><a href='javascript:0;' onclick='delet3("Work_Details",<?php echo $row['id']; ?>)' ><i class='fa fa-trash' ></a></td></tr>
                <?php $i++;
             }
          ?>  
        </tbody>
                                    </table>

                                </div>
                            </div> <!-- modal-content -->

                        </div> <!-- modal-dialog -->
                    </div>



<hr style="border: 1px solid #A2AEBB; margin-right: 10%" />​
<p class="contact"><label>Mention your personal skills</label></p>
<button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#pSkillsModal" style="position: relative; float: right; margin-right: 10%">Personal Skills</button><br><br>

                    <!-- Modal -->
 <div class="modal fade" id="pSkillsModal" role="dialog">
        <div class="modal-dialog">
 <div class="modal-content">
     <div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
   <h4 class="modal-title">Personal Skills</h4>
                                </div>
     <div class="modal-body">
     <div class="form-group" id="pSkillInput">
<label for="pSkill">your Personal Skills</label><br><br>
    <input class="form-control inputName" id="skills" type="text" placeholder="Project Management, business strategies etc..">
<button type="button" class="btn btn-primary" onclick="addqual('skills')">Add Skill</button>
                                    </div>
                                </div>
                    <div class="modal-footer">
     <table class="table table-striped table-hover table-users">
      <thead><tr><td>Sno</td><td><strong>Personal Skills</strong></td><td>Action</td></tr> </thead>
         <tbody id="skills_table">
            <?php  $sql="select * from skills where user_id=".$_SESSION['userid'];
            $result=mysqli_query($con,$sql); $i=1;
            while ($row=mysqli_fetch_array($result)) {
                echo "<tr><td>".$i."</td><td>".$row['2']."</td>"; ?> 
    <td><a href='javascript:0;' onclick='delet("skills",<?php echo $row['id']; ?>)' ><i class='fa fa-trash' ></a></td></tr>
                <?php $i++;
             } ?> 
        </tbody>
                                    </table>

                                </div>
                            </div> <!-- modal-content -->

                        </div> <!-- modal-dialog -->
                    </div>


          <hr style="border: 1px solid #A2AEBB; margin-right: 10%" />​
          <p class="contact"><label>Mention your Technical skills</label></p>
    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#tSkillsModal" style="position: relative; float: right; margin-right: 10%">Technical Skills</button><br><br>

                    <!-- Modal -->
                    <div class="modal fade" id="tSkillsModal" role="dialog">
                        <div class="modal-dialog">
   <div class="modal-content">
       <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title">Technical Skills</h4>
                                </div>
     <div class="modal-body">
     <div class="form-group" id="tSkillInput">
<label for="tSkill">Add your Technical Skills</label><br><br>
  <input class="form-control inputName" id="technical_skills" type="text" placeholder="Photoshop, MVC, .net, node.js etc..">

                                    </div>
                                </div>
               <div class="modal-footer">
<button type="button" class="btn btn-primary" onclick="addqual('technical_skills');">Save Changes</button>
      <table class="table table-striped table-hover table-users">
        <thead> <tr><td>Sno</td><td><strong>Technical Skills</strong></td><td>Action</td></tr></thead>
        <tbody id="technical_skills_table">
            <?php  $sql="select * from technical_skills where user_id=".$_SESSION['userid'];
            $result=mysqli_query($con,$sql); $i=1;
            while ($row=mysqli_fetch_array($result)) {
                echo "<tr><td>".$i."</td><td>".$row['2']."</td>"; ?> 
    <td><a href='javascript:0;' onclick='delet("technical_skills",<?php echo $row['id']; ?>)' ><i class='fa fa-trash' ></a></td></tr>
                <?php $i++;
             } ?> 
        </tbody>
                                    </table>

                                </div>
                            </div> <!-- modal-content -->

                        </div> <!-- modal-dialog -->
                    </div>


<hr style="border: 1px solid #A2AEBB; margin-right: 10%" />​
<button class="buttom"  type="submit" style="position: relative; float: right; margin-right: 10%">Save your information</button><br><br>
<hr style="border: 1px solid #A2AEBB; margin-right: 10%" />​
<center><button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#tempSelectModal" style="position: relative;margin-right: 10%">Print Resume</button></center><br><br>

</div>
</form>

    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <h5>Go Resume</h5>
                </div>
                <div class="col-sm-6 social-icons"><a href="https://www.facebook.com/Go-Resume-1813690295611919/" target="_blank"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-instagram"></i></a></div>
            </div>
        </div>
    </footer>
</div>
<script type="text/javascript">
        function addexp(){
          position=$('#position').val();
          org=$('#org').val();
          start=$('#start').val();
          end=$('#end').val();
          $.ajax({  
                     url:"ajax_exp.php",  
                     method:"post",  
                     data:{position:position,org:org,start:start,end:end},  
                     dataType:"text",  
                     success:function(data)  
                     {  
                        $('#position').val('');
                        $('#org').val('');
                        $('#exp_table').html( data );
                     }  
                });
        }
        function delet3(name,id){
        $.ajax({  
                     url:"ajax_exp.php",  
                     method:"post",  
                     data:{delete:id,table:name},  
                     dataType:"text",  
                     success:function(data)  
                     {  
                        $('#exp_table').html( data );
                       
                     }  
                });
    }
           function add_edu(){
            degree=$('#edu_degree').val();
            institute=$('#edu_institute').val();
            date=$('#edu_date').val();
            $.ajax({  
                     url:"ajax_edu.php",  
                     method:"post",  
                     data:{degree:degree,institute:institute,date:date},  
                     dataType:"text",  
                     success:function(data)  
                     {  
                        $('#edu_degree').val('');
                        $('#edu_institute').val('');
                        $('#edu_date').val('');
                        $('#edu_table').html( data );
                     }  
                });
           }
    function delet2(name,id){
        $.ajax({  
                     url:"ajax_edu.php",  
                     method:"post",  
                     data:{delete:id,table:name},  
                     dataType:"text",  
                     success:function(data)  
                     {  
                        $('#edu_table').html( data );
                       
                     }  
                });
    }
    function delet(name,id){
        $.ajax({  
                     url:"ajax.php",  
                     method:"post",  
                     data:{delete:id,table:name},  
                     dataType:"text",  
                     success:function(data)  
                     {  
                        $('#'+name+'_table').html( data );
                       
                     }  
                });
    }
    function addqual(name) {
        var valu=$('#'+name).val();
          $.ajax({  
                     url:"ajax.php",  
                     method:"post",  
                     data:{data:valu,table:name},  
                     dataType:"text",  
                     success:function(data)  
                     {  
                        $('#'+name).val('');
                        $('#'+name+'_table').html( data );
                     }  
                });
    }
</script>    


</body>
</html>
