<?php 
session_start();
include 'include/conn.php';
include 'include/header.php';
if (isset($_SESSION['userid'])) {
    $userid=$_SESSION['userid'];
}else{
    $userid=0;
}
?>

<body style="font-family:Sansation Light;background-color:#EDEBEB;">
<script src="include/sweetalert.js"></script>
<?php  if(isset($_GET['msg']) && $_GET['msg']=='inserted'){ ?>
<script type="text/javascript">
swal("Good job!", "Sign Up Successfully!", "success");
</script>
<?php }elseif(isset($_GET['msg']) && $_GET['msg']=='login'){ ?>
<script type="text/javascript">
swal("Good job!", "LOGIN Successfully!", "success");
</script>
<?php }elseif(isset($_GET['msg']) && $_GET['msg']=='nologin'){ ?>
<script type="text/javascript">
swal("Ouch!", "Email OR Password is Wrong!", "error");
</script>
<?php }elseif (isset($_GET['msg'])) {  ?>
<script type="text/javascript">
   swal("Ouch!", "Try again!", "error");
</script>
<?php } ?>
    <div id="status"></div>

    <?php include 'include/nav.php'; ?>

    <div class="hero2" style="font-family:Sansation Light">
        <div class="container">
            <div class="row">
                <div class="col-md-12 get-it">
                    <h1 class="text-muted">Jobs Board</h1>
    <p>
<a class="btn btn-primary btn-lg" role="button" onclick="fun(1);" target="_self">All Jobs</a>
<a class="btn btn-primary btn-lg" role="button" onclick="fun('Web Development');" target="_self">Web Development</a>
<a class="btn btn-primary btn-lg" role="button" onclick="fun('Web Desiging');" target="_self">Web Desiging</a>
<a class="btn btn-primary btn-lg" role="button" onclick="fun('Graphics Designer');" target="_self">Graphics Designer</a>
<a class="btn btn-primary btn-lg" role="button" onclick="fun('Unity Development');" target="_self">Unity Development</a>
<a class="btn btn-primary btn-lg" role="button" onclick="fun('Andriod Apps Development');" target="_self">Andriod Apps Development</a>
<a class="btn btn-primary btn-lg" role="button" onclick="fun('IOS Apps Development');" target="_self">IOS Apps Development</a>
<a class="btn btn-primary btn-lg" role="button" onclick="fun('Others');" target="_self">Others</a>
    
                    </p>
                </div>
            </div>
        </div>
    </div>

    <section class="testimonials" style="font-family:Sansation Light">
        <?php 
        if (isset($_GET['categiory'])) {
       $sql="SELECT company.name,company.email, jobs.* FROM jobs LEFT JOIN company ON jobs.cid = company.id where category='".$_GET['categiory']."'";
       echo '<h3 class="job-left">'.$_GET['categiory'].' Jobs!</h3>';
        }else{
$sql="SELECT company.name,company.email, jobs.* FROM jobs LEFT JOIN company ON jobs.cid = company.id ORDER BY jobs.id DESC";
echo '<h3 class="job-left">All Jobs!</h3>';
        }
        
        $result=mysqli_query($con,$sql);
        $num=mysqli_num_rows($result);
        if ($num<1) {
            echo "<center><h3>No Post Found!</h3></center>";
        }
        foreach ($result as $row ) { ?>
       <div class="job-box">
            <p class="job-title"><?php echo $row['title']; ?></p>
            <p class="job-left"><?php echo $row['name']; ?></p>
            <table class="apply-table"><tr class="tr-color">
<td>Job Type</td><td>Job Shift</td><td>Experience</td><td>Salary</td></tr><tr>
<td><?php echo $row['status']; ?></td>
<td><?php echo $row['time']; ?></td>
<td><?php echo $row['experience']; ?></td>
<td><?php echo $row['salary']; ?></td>
           </tr>
            </table>
<p class="job-left"><?php echo $row['description']; ?></p>
<span class="job-left">Job Location: <?php echo $row['location']; ?></span>
<a class="btn btn-primary btn-lg apply-btn" role="button" onclick="apply(<?php echo $row['id']; ?>,<?php echo $userid; ?>);" target="_self">Apply Now</a>
        </div>
        <br>
 <?php  } ?>
    </section>
    <!-- <section class="features">
        <div class="container">
            <div class="row">
                <div class="col-md-6" style="font-family:Sansation Light">
                    <h2>Fantastic Features</h2>
                    <p>Create unlimited resumes, Publish them, share them. Explore for jobs</p>
                </div>
                <div class="col-md-6" style="font-family:Sansation Light">
                    <div class="row icon-features">
                        <div class="col-xs-4 icon-feature"><i class="glyphicon glyphicon-flash"></i>
                            <p>Fast</p>
                        </div>
                        <div class="col-xs-4 icon-feature"><i class="glyphicon glyphicon-piggy-bank"></i>
                            <p>Free</p>
                        </div>
                        <div class="col-xs-4 icon-feature"><i class="glyphicon glyphicon-hand-right"></i>
                            <p>Secure</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <h5>Go Resume</h5>
                </div>
                <div class="col-sm-6 social-icons"><a href="https://www.facebook.com/Go-Resume-1813690295611919/" target="_blank"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-instagram"></i></a></div>
            </div>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
<script type="text/javascript">
    function fun(name) {
        if (name==1) {
window.open('jobs.php','_self');
        }else{
window.open('jobs.php?categiory='+name,'_self');
        }
      exit();
    }
    function apply(id,userid) {
    if (userid != 0) {
        $.ajax({
            url:"action.php",
            method:"post",
            data:{apply_id:id},
            dataType:'text',
            success:function(data){
                if (data==1) {
    swal("Good job!", "Apply Successfully!", "success");
                }else{
        swal(data);
                }
            }
        });
    } else{
 $('#myModal3').modal('toggle');
    }                                          
    }                                                
</script>
<style type="text/css">
    .job-title{
      padding-top: 10px;padding-left:10px;margin-bottom: 0px;color: #283593;"
    }
    .job-left{
      padding-left: 10px;
    }
    .job-box{
        background-color: white;width: 60%;margin-left: 20%;
    }
    .apply-table {
      width: 100%;
     margin-bottom: 2px;
     margin-left: 10px;
   }
   .tr-color{
    color: #93a6af;
   }
.apply-btn{
   margin-bottom: 10px;
   margin-left: 60%;
}
.testimonials {
    margin-top: 1px !important;
}
</style>
<div class="modal fade" id="myModal3" role="dialog">
    <div class="modal-dialog">
     <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Login Go Resume</h4>
        </div>
<form class="form-horizontal" action="action.php" method="POST" >
<div class="modal-body">

  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="email" placeholder="Your Email" pattern="^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$" title="Please Enter Email Address" required>
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" name="password" placeholder="Password" required>
    </div>
  </div>
         
        </div>
        <div class="modal-footer">
            <input type="hidden" name="login">
            <input type="hidden" name="joblogin">
<button type="submit"  class="btn btn-info">LOG IN</button>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>        </div>
</form>

      </div>
      
    </div>
  </div>
  <!-- modal end -->