/**
 * Created by AdeelAhmedMirza on 7/19/2017.
 */
// Ready the data to be displayed in the template - START

var gName = localStorage.getItem("sName");
var gEmail = localStorage.getItem("sEmail");
var gPhone = localStorage.getItem("sPhone");
var gAddress = localStorage.getItem("sAddress");
var gHistory = localStorage.getItem("sHistory");
var gDob = localStorage.getItem("sDob");
var gAbout = localStorage.getItem("sAbout");
var gEdu = localStorage.getItem("sEdu");
var gEduc = JSON.parse(gEdu);
var gWor = localStorage.getItem("sWork");
var gWork = JSON.parse(gWor);
var gPSkills = localStorage.getItem("sPSkill");
var gPSkill = JSON.parse(gPSkills);
var gTSkills = localStorage.getItem("sTSkill");
var gTSkill = JSON.parse(gTSkills);
var gQuals = localStorage.getItem("sQual");
var gQual = JSON.parse(gQuals)


// Ready the data to be displayed in the template - END

