<?php 
session_start();
include 'include/conn.php';
include 'include/header.php';
?>

<body style="font-family:Sansation Light">
<script src="include/sweetalert.js"></script>
<?php  if(isset($_GET['msg']) && $_GET['msg']=='inserted'){ ?>
<script type="text/javascript">
swal("Good job!", "Sign Up Successfully!", "success");
</script>
<?php }elseif(isset($_GET['msg']) && $_GET['msg']=='login'){ ?>
<script type="text/javascript">
swal("Good job!", "LOGIN Successfully!", "success");
</script>
<?php }elseif(isset($_GET['msg']) && $_GET['msg']=='nologin'){ ?>
<script type="text/javascript">
swal("Ouch!", "Email OR Password is Wrong!", "error");
</script>
<?php }elseif (isset($_GET['msg'])) {  ?>
<script type="text/javascript">
   swal("Ouch!", "Try again!", "error");
</script>
<?php } ?>
    <div id="status"></div>

    <?php include 'include/nav.php'; ?>


    <section class="features">
        <div class="container">
            <div class="row">
                <div class="col-md-4" style="font-family:Sansation Light">
                    <h2>Candidates applications</h2>
  <p><i class="fa fa-hand-o-right"></i><a href="jobs_post.php" style="color: white;">Post A Job</a></p>
  <p><i class="fa fa-hand-o-right"></i><a href="all_jobs.php" style="color: white;"> All Jobs</a></p>
                </div>
                <div class="col-md-8" style="font-family:Sansation Light">
  <?php $sql="select * from jobs where cid=".$_SESSION['cid'];
  $result=mysqli_query($con,$sql);
$num=mysqli_num_rows($result);
   ?>
  <div class="form-group row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Post Title</label>
    <div class="col-sm-10">
       <select class="form-control" id="title">
         <?php $i=0; foreach ($result as $row) {
         if ($i==0) {
         	$id=$row['id'];
         	$i++;
         }
          ?>
          <option value="<?php echo $row['id']; ?>"><?php echo $row['title']; ?></option>
       <?php  } ?>
       </select>
    </div>
  </div>
  <h4 style="color: white;">The following Canditades apply for this job.Click on his name for applicant detail!</h4>
  <?php if ($num>0) { 
  $sql="select users.id,name from users LEFT JOIN applications ON users.id=applications.applicant_id where post_id=".$id;
  $result=mysqli_query($con,$sql);
  echo "<div id='applications'>";
  $num2=mysqli_num_rows($result);
  if ($num2>0) {
  foreach ($result as $key) {  ?>
  	<a href="templates\profile.php?id=<?php  echo $key['id']; ?>" class="btn btn-success" title="See <?php  echo $key['name']; ?> resume"><?php  echo $key['name']; ?></a>
  <?php }
      }else{
  	echo '<h3 style="color:white">No Applications Submited Yet!</h3>';
  }
   ?>
  </div>
  <?php }else{
  	echo "<h3 style='color:white'>You Didn't Post Yet!</h3>";
  } ?>
  
                </div>
            </div>
        </div>
    </section>
    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <h5><a href="index.html"> Go Resume</a></h5>
                </div>
                <div class="col-sm-6 social-icons"><a href="https://www.facebook.com/Go-Resume-1813690295611919/" target="_blank"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-instagram"></i></a></div>
            </div>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>
<script type="text/javascript">
	$( "#title" ).change(function() {
  var id=$("#title").val();
  $.ajax({  
                     url:"ajax_app.php",  
                     method:"post",  
                     data:{id:id},  
                     dataType:"text",  
                     success:function(data)  
                     {  
                       $('#applications').html( data );
                     }  
                });
});
</script>
</html>
