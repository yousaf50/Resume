<?php 
session_start();
include 'include/conn.php';
include 'include/header.php';
?>

<body style="font-family:Sansation Light">
<script src="include/sweetalert.js"></script>
<?php  if(isset($_GET['msg']) && $_GET['msg']=='inserted'){ ?>
<script type="text/javascript">
swal("Good job!", "Job Post Successfully!", "success");
</script>
<?php }elseif(isset($_GET['msg']) && $_GET['msg']=='delete'){ ?>
<script type="text/javascript">
swal("Good job!", "Delete Successfully!", "success");
</script>
<?php }elseif(isset($_GET['msg']) && $_GET['msg']=='nologin'){ ?>
<script type="text/javascript">
swal("Ouch!", "Email OR Password is Wrong!", "error");
</script>
<?php }elseif(isset($_GET['msg']) && $_GET['msg']=='updated'){ ?>
<script type="text/javascript">
swal("Good job!", "Post Update Successfully!", "success");
</script>
<?php }elseif (isset($_GET['msg'])) {  ?>
<script type="text/javascript">
   swal("Ouch!", "Try again!", "error");
</script>
<?php } ?>
    <div id="status"></div>

    <?php include 'include/nav.php'; ?>


    <section class="features">
        <div class="container">
            <div class="row">
                <div class="col-md-2" style="font-family:Sansation Light">
  <h2>All Jobs</h2>
  <p><i class="fa fa-hand-o-right"></i><a href="jobs_post.php" style="color: white;">Post A Job</a></p>
  <p><i class="fa fa-hand-o-right"></i><a href="applications.php" style="color: white;">Candidates applications</a></p>
                </div>
                <div class="col-md-10" style="font-family:Sansation Light">
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Title</th>
      <th scope="col">Description</th>
      <th scope="col">Category</th>
      <th scope="col">locaton</th>
      <th scope="col">Status</th>
      <th scope="col">Salary</th>
      <th scope="col">Time</th>
      <th scope="col">Experience</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php $sql="select * from jobs where cid=".$_SESSION['cid'];
$result=mysqli_query($con,$sql);
$i=1;
while ($row=mysqli_fetch_array($result)) {  ?>
   <tr>
      <th scope="row"><?php echo $i++; ?></th>
      <td><?php echo $row['title']; ?></td>
      <td><?php echo $row['description']; ?></td>
      <td><?php echo $row['category']; ?></td>
      <td><?php echo $row['location']; ?></td>
      <td><?php echo $row['status']; ?></td>
      <td><?php echo $row['salary']; ?></td>
      <td><?php echo $row['time']; ?></td>
      <td><?php echo $row['experience']; ?></td>
      <td><a href="edit_job.php?id=<?php echo $row['id']; ?>"><i class="fa fa-edit"></i></a><a href="#" onclick="delet(<?php echo $row['id']; ?>);"><i class="fa fa-trash"></i></></td>
    </tr>
<?php } 
?>
  </tbody>
</table>
<?php if ($i==1) { ?>
   <h3 style="color:white;"><center>No Job Post Found! </center></h3>
 <?php } ?>
                </div>
            </div>
        </div>
    </section>
    <script type="text/javascript">
      function delet(id) {
        swal({
  title: "Are you sure?",
  text: "Once deleted, you will not be able to recover this post!",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {
    window.open('action.php?did='+id,'_self');
    exit();
    /*swal("Poof! Your post has been deleted!", {
      icon: "success",
    });*/
  } else {
    
  }
});
      }
    </script>
    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <h5><a href="index.html"> Go Resume</a></h5>
                </div>
                <div class="col-sm-6 social-icons"><a href="https://www.facebook.com/Go-Resume-1813690295611919/" target="_blank"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-instagram"></i></a></div>
            </div>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>
<style type="text/css">
  tr{
    border-color: white;
    border-bottom-style: outset;
  }
  .fa-edit ,.fa-trash{
    color: white;
font-size: 30px;
  }
</style>
</html>
